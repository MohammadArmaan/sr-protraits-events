module.exports=[25084,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_admin_me_route_actions_23549f68.js.map