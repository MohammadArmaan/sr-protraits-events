module.exports=[81436,(e,o,d)=>{}];

//# sourceMappingURL=6aa0a_next-internal_server_app_api_vendors_products_categories_route_actions_cd42caa6.js.map