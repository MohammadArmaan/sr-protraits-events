module.exports=[67010,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_admin_profile-edits_reject_route_actions_6da7917f.js.map