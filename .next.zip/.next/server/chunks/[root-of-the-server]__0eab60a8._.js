module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},24361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},88947,(e,t,r)=>{t.exports=e.x("stream",()=>require("stream"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},27699,(e,t,r)=>{t.exports=e.x("events",()=>require("events"))},92509,(e,t,r)=>{t.exports=e.x("url",()=>require("url"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},21517,(e,t,r)=>{t.exports=e.x("http",()=>require("http"))},24836,(e,t,r)=>{t.exports=e.x("https",()=>require("https"))},6461,(e,t,r)=>{t.exports=e.x("zlib",()=>require("zlib"))},46786,(e,t,r)=>{t.exports=e.x("os",()=>require("os"))},54535,e=>{"use strict";var t=e.i(60914);async function r({to:e,subject:r,html:a,attachments:n}){try{let o=t.default.createTransport({service:"gmail",auth:{user:process.env.GMAIL_EMAIL,pass:process.env.GMAIL_APP_PASSWORD}});return await o.sendMail({from:`SR Portraits & Events <${process.env.GMAIL_EMAIL}>`,to:e,subject:r,html:a,attachments:n}),{success:!0}}catch(e){return console.error("Email Send Error:",e),{success:!1,error:e}}}e.s(["sendEmail",()=>r])},65891,e=>{"use strict";var t=e.i(3745),r=e.i(59145),a=e.i(19643),n=e.i(5896),o=e.i(53795),s=e.i(42009),i=e.i(1654),l=e.i(1630),d=e.i(89727),p=e.i(71366),u=e.i(19441),c=e.i(44235),x=e.i(57281),v=e.i(477),h=e.i(52186),m=e.i(73929),f=e.i(93695);e.i(28633);var g=e.i(18897),y=e.i(83111),R=e.i(85881),b=e.i(97736),w=e.i(50170),E=e.i(67389),A=e.i(54535);async function T(e){try{var t;let r,a=e.cookies.get("admin_token")?.value;if(!a)return y.NextResponse.json({error:"Unauthorized: Admin login required"},{status:401});try{r=E.default.verify(a,process.env.JWT_SECRET)}catch{return y.NextResponse.json({error:"Invalid or expired admin token"},{status:401})}if("admin"!==r.role&&"superadmin"!==r.role)return y.NextResponse.json({error:"Permission denied: Only admins can approve vendors"},{status:403});let{vendorId:n}=await e.json();if(!n)return y.NextResponse.json({error:"vendorId is required"},{status:400});let[o]=await R.db.select().from(b.vendorsTable).where((0,w.eq)(b.vendorsTable.id,n));if(!o)return y.NextResponse.json({error:"Vendor not found"},{status:404});if(o.isApproved)return y.NextResponse.json({error:"Vendor is already approved"},{status:400});let s=E.default.sign({vendorId:n},process.env.JWT_SECRET,{expiresIn:"48h"}),i=new Date(Date.now()+1728e5);await R.db.update(b.vendorsTable).set({status:"AWAITING_ACTIVATION",activationToken:s,activationTokenExpires:i,isApproved:!0,approvedAt:new Date}).where((0,w.eq)(b.vendorsTable.id,n));let l=`/api/vendors/activate?token=${s}`;return await (0,A.sendEmail)({to:o.email,subject:"Your Vendor Account is Approved 🎉",html:(t=o.fullName,`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;padding:0;margin:0;font-family:Arial,sans-serif;">

    <table width="600" align="center" cellpadding="0" cellspacing="0"
           style="background:white;margin:20px auto;border-radius:12px;
                  border:1px solid #e5e5e5;overflow:hidden;">

      <!-- HEADER -->
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" style="margin-bottom:10px;" />
          <h1 style="margin:0;font-size:26px;color:hsl(222,47%,11%);">
            SR Portraits & Events
          </h1>
        </td>
      </tr>

      <!-- BODY -->
      <tr>
        <td style="padding:35px 40px;text-align:center;">

          <h2 style="margin-bottom:10px;font-size:24px;color:hsl(222,47%,11%);">
            Welcome aboard, ${t}! 🎉
          </h2>

          <p style="font-size:16px;color:#444;margin-bottom:22px;">
            Your vendor application has been <strong>approved</strong> by our team.
            You can now activate your account and access your vendor dashboard.
          </p>

          <!-- IMPORTANT NOTE -->
          <p style="font-size:15px;color:#555;margin-bottom:22px;">
            <strong>Important:</strong> To ensure smooth and timely payouts, we require
            verified bank details before any services can go live on the platform.
          </p>

          <p style="font-size:15px;color:#555;margin-bottom:28px;">
            Once your account is activated, please complete your payout information
            from your profile. Our team will only create vendor service listings
            after payout details are submitted and verified.
          </p>

          <!-- ACTIVATE BUTTON -->
          <a href="${process.env.DOMAIN}${l}"
             style="
                display:inline-block;
                padding:16px 36px;
                font-size:16px;
                font-weight:bold;
                color:white;
                text-decoration:none;
                border-radius:9999px;
                background:linear-gradient(135deg, hsl(220, 80%, 55%), hsl(180, 70%, 50%));
                box-shadow:0 8px 32px -8px rgba(0,0,0,0.25);
                margin-top:10px;
             ">
            Activate My Account
          </a>

          <p style="margin-top:28px;color:#666;font-size:14px;">
            If you did not request this approval, you can safely ignore this email.
          </p>

        </td>
      </tr>

      <!-- FOOTER -->
      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;color:#777;font-size:12px;">
          &copy; ${new Date().getFullYear()} SR Portraits & Events. All rights reserved.
        </td>
      </tr>

    </table>

  </body>
</html>
`)}),y.NextResponse.json({success:!0,message:"Vendor approved and activation email sent."})}catch(e){return console.error("Admin Approve Vendor Error:",e),y.NextResponse.json({error:"Internal server error"},{status:500})}}e.s(["POST",()=>T],31289);var C=e.i(31289);let N=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/admin/vendor-registration/approve/route",pathname:"/api/admin/vendor-registration/approve",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/admin/vendor-registration/approve/route.ts",nextConfigOutput:"",userland:C}),{workAsyncStorage:q,workUnitAsyncStorage:O,serverHooks:k}=N;function I(){return(0,a.patchFetch)({workAsyncStorage:q,workUnitAsyncStorage:O})}async function P(e,t,a){N.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let y="/api/admin/vendor-registration/approve/route";y=y.replace(/\/index$/,"")||"/";let R=await N.prepare(e,t,{srcPage:y,multiZoneDraftMode:!1});if(!R)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:b,params:w,nextConfig:E,parsedUrl:A,isDraftMode:T,prerenderManifest:C,routerServerContext:q,isOnDemandRevalidate:O,revalidateOnlyGenerated:k,resolvedPathname:I,clientReferenceManifest:P,serverActionsManifest:S}=R,j=(0,l.normalizeAppPath)(y),_=!!(C.dynamicRoutes[j]||C.routes[I]),M=async()=>((null==q?void 0:q.render404)?await q.render404(e,t,A,!1):t.end("This page could not be found"),null);if(_&&!T){let e=!!C.routes[I],t=C.dynamicRoutes[j];if(t&&!1===t.fallback&&!e){if(E.experimental.adapterPath)return await M();throw new f.NoFallbackError}}let D=null;!_||N.isDev||T||(D="/index"===(D=I)?"/":D);let H=!0===N.isDev||!_,U=_&&!H;S&&P&&(0,s.setReferenceManifestsSingleton)({page:y,clientReferenceManifest:P,serverActionsManifest:S,serverModuleMap:(0,i.createServerModuleMap)({serverActionsManifest:S})});let $=e.method||"GET",z=(0,o.getTracer)(),F=z.getActiveScopeSpan(),L={params:w,prerenderManifest:C,renderOpts:{experimental:{authInterrupts:!!E.experimental.authInterrupts},cacheComponents:!!E.cacheComponents,supportsDynamicResponse:H,incrementalCache:(0,n.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:E.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a)=>N.onRequestError(e,t,a,q)},sharedContext:{buildId:b}},V=new d.NodeNextRequest(e),K=new d.NodeNextResponse(t),B=p.NextRequestAdapter.fromNodeNextRequest(V,(0,p.signalFromNodeResponse)(t));try{let s=async e=>N.handle(B,L).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=z.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${$} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${$} ${y}`)}),i=!!(0,n.getRequestMeta)(e,"minimalMode"),l=async n=>{var o,l;let d=async({previousCacheEntry:r})=>{try{if(!i&&O&&k&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await s(n);e.fetchMetrics=L.renderOpts.fetchMetrics;let l=L.renderOpts.pendingWaitUntil;l&&a.waitUntil&&(a.waitUntil(l),l=void 0);let d=L.renderOpts.collectedTags;if(!_)return await (0,x.sendResponse)(V,K,o,L.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),t=(0,v.toNodeOutgoingHttpHeaders)(o.headers);d&&(t[m.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==L.renderOpts.collectedRevalidate&&!(L.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&L.renderOpts.collectedRevalidate,a=void 0===L.renderOpts.collectedExpire||L.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:L.renderOpts.collectedExpire;return{value:{kind:g.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await N.onRequestError(e,t,{routerKind:"App Router",routePath:y,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:O})},q),t}},p=await N.handleResponse({req:e,nextConfig:E,cacheKey:D,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:C,isRoutePPREnabled:!1,isOnDemandRevalidate:O,revalidateOnlyGenerated:k,responseGenerator:d,waitUntil:a.waitUntil,isMinimalMode:i});if(!_)return null;if((null==p||null==(o=p.value)?void 0:o.kind)!==g.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",O?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),T&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let u=(0,v.fromNodeOutgoingHttpHeaders)(p.value.headers);return i&&_||u.delete(m.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||u.get("Cache-Control")||u.set("Cache-Control",(0,h.getCacheControlHeader)(p.cacheControl)),await (0,x.sendResponse)(V,K,new Response(p.value.body,{headers:u,status:p.value.status||200})),null};F?await l(F):await z.withPropagatedContext(e.headers,()=>z.trace(u.BaseServerSpan.handleRequest,{spanName:`${$} ${y}`,kind:o.SpanKind.SERVER,attributes:{"http.method":$,"http.target":e.url}},l))}catch(t){if(t instanceof f.NoFallbackError||await N.onRequestError(e,t,{routerKind:"App Router",routePath:j,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:O})}),_)throw t;return await (0,x.sendResponse)(V,K,new Response(null,{status:500})),null}}e.s(["handler",()=>P,"patchFetch",()=>I,"routeModule",()=>N,"serverHooks",()=>k,"workAsyncStorage",()=>q,"workUnitAsyncStorage",()=>O],65891)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0eab60a8._.js.map