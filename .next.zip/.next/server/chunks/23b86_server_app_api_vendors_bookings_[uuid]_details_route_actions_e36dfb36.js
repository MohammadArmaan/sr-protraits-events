module.exports=[33728,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_vendors_bookings_%5Buuid%5D_details_route_actions_e36dfb36.js.map