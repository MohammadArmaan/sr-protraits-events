module.exports=[91671,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_admin_vendor-banners_list_route_actions_d554f7e9.js.map