module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},24361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},88947,(e,t,r)=>{t.exports=e.x("stream",()=>require("stream"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},27699,(e,t,r)=>{t.exports=e.x("events",()=>require("events"))},92509,(e,t,r)=>{t.exports=e.x("url",()=>require("url"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},21517,(e,t,r)=>{t.exports=e.x("http",()=>require("http"))},24836,(e,t,r)=>{t.exports=e.x("https",()=>require("https"))},6461,(e,t,r)=>{t.exports=e.x("zlib",()=>require("zlib"))},46786,(e,t,r)=>{t.exports=e.x("os",()=>require("os"))},54535,e=>{"use strict";var t=e.i(60914);async function r({to:e,subject:r,html:s,attachments:n}){try{let o=t.default.createTransport({service:"gmail",auth:{user:process.env.GMAIL_EMAIL,pass:process.env.GMAIL_APP_PASSWORD}});return await o.sendMail({from:`SR Portraits & Events <${process.env.GMAIL_EMAIL}>`,to:e,subject:r,html:s,attachments:n}),{success:!0}}catch(e){return console.error("Email Send Error:",e),{success:!1,error:e}}}e.s(["sendEmail",()=>r])},59485,(e,t,r)=>{t.exports=e.x("@aws-sdk/client-s3",()=>require("@aws-sdk/client-s3"))},21422,e=>{"use strict";var t=e.i(3745),r=e.i(59145),s=e.i(19643),n=e.i(5896),o=e.i(53795),a=e.i(42009),i=e.i(1654),l=e.i(1630),d=e.i(89727),p=e.i(71366),u=e.i(19441),c=e.i(44235),x=e.i(57281),h=e.i(477),g=e.i(52186),f=e.i(73929),m=e.i(93695);e.i(28633);var v=e.i(18897),y=e.i(83111),R=e.i(85881),E=e.i(97736),b=e.i(50170),w=e.i(67389),A=e.i(59485),C=e.i(54535);let S=new A.S3Client({region:process.env.AWS_REGION,credentials:{accessKeyId:process.env.AWS_ACCESS_KEY_Id,secretAccessKey:process.env.AWS_SECRET_ACCESS_Key}});async function T(e){try{var t;let r,s=e.cookies.get("admin_token")?.value;if(!s)return y.NextResponse.json({error:"Unauthorized"},{status:401});try{r=w.default.verify(s,process.env.JWT_SECRET)}catch{return y.NextResponse.json({error:"Invalid token"},{status:401})}if("admin"!==r.role&&"superadmin"!==r.role)return y.NextResponse.json({error:"Permission denied"},{status:403});let{vendorId:n}=await e.json();if(!n)return y.NextResponse.json({error:"vendorId is required"},{status:400});let[o]=await R.db.select().from(E.vendorsTable).where((0,b.eq)(E.vendorsTable.id,n));if(!o)return y.NextResponse.json({error:"Vendor not found"},{status:404});let a=async e=>{let t=e?.split(".com/")[1];if(t)try{await S.send(new A.DeleteObjectCommand({Bucket:process.env.AWS_S3_BUCKET_NAME,Key:t}))}catch(e){console.error("S3 Delete Error:",e)}};if(o.profilePhoto&&await a(o.profilePhoto),Array.isArray(o.businessPhotos))for(let e of o.businessPhotos)await a(e);return await R.db.update(E.vendorsTable).set({status:"REJECTED",isApproved:!1}).where((0,b.eq)(E.vendorsTable.id,n)),await (0,C.sendEmail)({to:o.email,subject:"Your Vendor Registration Was Rejected ❌",html:(t=o.fullName||o.businessName||"Vendor",`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;padding:0;margin:0;font-family:Arial,sans-serif;">

    <table width="600" align="center" cellpadding="0" cellspacing="0"
           style="background:white;margin:20px auto;border-radius:12px;
                  border:1px solid #e5e5e5;overflow:hidden;">

      <!-- HEADER -->
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" style="margin-bottom:10px;" />
          <h1 style="margin:0;font-size:26px;color:hsl(222,47%,11%);">
            SR Portraits & Events
          </h1>
        </td>
      </tr>

      <!-- BODY -->
      <tr>
        <td style="padding:35px 40px;text-align:center;">

          <h2 style="margin-bottom:10px;font-size:24px;color:hsl(222,47%,11%);">
            Hi, ${t}
          </h2>

          <p style="font-size:16px;color:#444;margin-bottom:20px;">
            We appreciate your interest in joining our vendor community.
          </p>

          <p style="font-size:16px;color:#444;margin-bottom:25px;">
            After carefully reviewing your registration details, we regret to inform you that your 
            <strong>vendor registration request has been rejected</strong>.
          </p>

          <p style="font-size:15px;color:#666;margin-bottom:25px;">
            This decision may be due to missing information, incorrect details, or 
            not meeting the eligibility guidelines required for verification.
          </p>

          <a href="${process.env.DOMAIN}/vendor/register"
             style="
                display:inline-block;
                padding:16px 36px;
                font-size:16px;
                font-weight:bold;
                color:white;
                text-decoration:none;
                border-radius:9999px;
                background:linear-gradient(135deg, hsl(0, 80%, 55%), hsl(10, 70%, 50%));
                box-shadow:0 8px 32px -8px rgba(0,0,0,0.25);
                margin-top:20px;
             ">
            Apply Again
          </a>

          <p style="margin-top:28px;color:#666;font-size:14px;">
            If you believe this was a mistake, please reach out to our support team.
          </p>

        </td>
      </tr>

      <!-- FOOTER -->
      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;color:#777;font-size:12px;">
          &copy; ${new Date().getFullYear()} SR Portraits & Events. All rights reserved.
        </td>
      </tr>

    </table>

  </body>
</html>`)}),y.NextResponse.json({success:!0,message:"Vendor rejected successfully"},{status:200})}catch(e){return console.error("Vendor Reject Error:",e),y.NextResponse.json({error:"Server error"},{status:500})}}e.s(["POST",()=>T],76621);var j=e.i(76621);let q=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/admin/vendor-registration/reject/route",pathname:"/api/admin/vendor-registration/reject",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/admin/vendor-registration/reject/route.ts",nextConfigOutput:"",userland:j}),{workAsyncStorage:N,workUnitAsyncStorage:P,serverHooks:_}=q;function k(){return(0,s.patchFetch)({workAsyncStorage:N,workUnitAsyncStorage:P})}async function O(e,t,s){q.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let y="/api/admin/vendor-registration/reject/route";y=y.replace(/\/index$/,"")||"/";let R=await q.prepare(e,t,{srcPage:y,multiZoneDraftMode:!1});if(!R)return t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve()),null;let{buildId:E,params:b,nextConfig:w,parsedUrl:A,isDraftMode:C,prerenderManifest:S,routerServerContext:T,isOnDemandRevalidate:j,revalidateOnlyGenerated:N,resolvedPathname:P,clientReferenceManifest:_,serverActionsManifest:k}=R,O=(0,l.normalizeAppPath)(y),I=!!(S.dynamicRoutes[O]||S.routes[P]),M=async()=>((null==T?void 0:T.render404)?await T.render404(e,t,A,!1):t.end("This page could not be found"),null);if(I&&!C){let e=!!S.routes[P],t=S.dynamicRoutes[O];if(t&&!1===t.fallback&&!e){if(w.experimental.adapterPath)return await M();throw new m.NoFallbackError}}let D=null;!I||q.isDev||C||(D="/index"===(D=P)?"/":D);let H=!0===q.isDev||!I,U=I&&!H;k&&_&&(0,a.setReferenceManifestsSingleton)({page:y,clientReferenceManifest:_,serverActionsManifest:k,serverModuleMap:(0,i.createServerModuleMap)({serverActionsManifest:k})});let K=e.method||"GET",$=(0,o.getTracer)(),z=$.getActiveScopeSpan(),F={params:b,prerenderManifest:S,renderOpts:{experimental:{authInterrupts:!!w.experimental.authInterrupts},cacheComponents:!!w.cacheComponents,supportsDynamicResponse:H,incrementalCache:(0,n.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:w.cacheLife,waitUntil:s.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,s)=>q.onRequestError(e,t,s,T)},sharedContext:{buildId:E}},L=new d.NodeNextRequest(e),W=new d.NodeNextResponse(t),B=p.NextRequestAdapter.fromNodeNextRequest(L,(0,p.signalFromNodeResponse)(t));try{let a=async e=>q.handle(B,F).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=$.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=r.get("next.route");if(s){let t=`${K} ${s}`;e.setAttributes({"next.route":s,"http.route":s,"next.span_name":t}),e.updateName(t)}else e.updateName(`${K} ${y}`)}),i=!!(0,n.getRequestMeta)(e,"minimalMode"),l=async n=>{var o,l;let d=async({previousCacheEntry:r})=>{try{if(!i&&j&&N&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await a(n);e.fetchMetrics=F.renderOpts.fetchMetrics;let l=F.renderOpts.pendingWaitUntil;l&&s.waitUntil&&(s.waitUntil(l),l=void 0);let d=F.renderOpts.collectedTags;if(!I)return await (0,x.sendResponse)(L,W,o,F.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(o.headers);d&&(t[f.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==F.renderOpts.collectedRevalidate&&!(F.renderOpts.collectedRevalidate>=f.INFINITE_CACHE)&&F.renderOpts.collectedRevalidate,s=void 0===F.renderOpts.collectedExpire||F.renderOpts.collectedExpire>=f.INFINITE_CACHE?void 0:F.renderOpts.collectedExpire;return{value:{kind:v.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:s}}}}catch(t){throw(null==r?void 0:r.isStale)&&await q.onRequestError(e,t,{routerKind:"App Router",routePath:y,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:j})},T),t}},p=await q.handleResponse({req:e,nextConfig:w,cacheKey:D,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:S,isRoutePPREnabled:!1,isOnDemandRevalidate:j,revalidateOnlyGenerated:N,responseGenerator:d,waitUntil:s.waitUntil,isMinimalMode:i});if(!I)return null;if((null==p||null==(o=p.value)?void 0:o.kind)!==v.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",j?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),C&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let u=(0,h.fromNodeOutgoingHttpHeaders)(p.value.headers);return i&&I||u.delete(f.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||u.get("Cache-Control")||u.set("Cache-Control",(0,g.getCacheControlHeader)(p.cacheControl)),await (0,x.sendResponse)(L,W,new Response(p.value.body,{headers:u,status:p.value.status||200})),null};z?await l(z):await $.withPropagatedContext(e.headers,()=>$.trace(u.BaseServerSpan.handleRequest,{spanName:`${K} ${y}`,kind:o.SpanKind.SERVER,attributes:{"http.method":K,"http.target":e.url}},l))}catch(t){if(t instanceof m.NoFallbackError||await q.onRequestError(e,t,{routerKind:"App Router",routePath:O,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:j})}),I)throw t;return await (0,x.sendResponse)(L,W,new Response(null,{status:500})),null}}e.s(["handler",()=>O,"patchFetch",()=>k,"routeModule",()=>q,"serverHooks",()=>_,"workAsyncStorage",()=>N,"workUnitAsyncStorage",()=>P],21422)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__9f3b1af5._.js.map