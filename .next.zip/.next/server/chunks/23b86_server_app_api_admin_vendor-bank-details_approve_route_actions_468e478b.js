module.exports=[85921,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_admin_vendor-bank-details_approve_route_actions_468e478b.js.map