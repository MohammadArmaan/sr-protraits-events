module.exports=[89060,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_admin_profile-edits_list_route_actions_d4a834a5.js.map