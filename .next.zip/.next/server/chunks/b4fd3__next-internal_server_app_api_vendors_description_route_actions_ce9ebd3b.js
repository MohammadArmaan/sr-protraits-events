module.exports=[27497,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_description_route_actions_ce9ebd3b.js.map