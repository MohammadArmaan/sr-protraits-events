module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},24361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},88947,(e,t,r)=>{t.exports=e.x("stream",()=>require("stream"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},27699,(e,t,r)=>{t.exports=e.x("events",()=>require("events"))},92509,(e,t,r)=>{t.exports=e.x("url",()=>require("url"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},21517,(e,t,r)=>{t.exports=e.x("http",()=>require("http"))},24836,(e,t,r)=>{t.exports=e.x("https",()=>require("https"))},6461,(e,t,r)=>{t.exports=e.x("zlib",()=>require("zlib"))},46786,(e,t,r)=>{t.exports=e.x("os",()=>require("os"))},54535,e=>{"use strict";var t=e.i(60914);async function r({to:e,subject:r,html:a,attachments:n}){try{let s=t.default.createTransport({service:"gmail",auth:{user:process.env.GMAIL_EMAIL,pass:process.env.GMAIL_APP_PASSWORD}});return await s.sendMail({from:`SR Portraits & Events <${process.env.GMAIL_EMAIL}>`,to:e,subject:r,html:a,attachments:n}),{success:!0}}catch(e){return console.error("Email Send Error:",e),{success:!1,error:e}}}e.s(["sendEmail",()=>r])},19566,e=>{"use strict";var t=e.i(71920),r=e.i(79559),a=e.i(28500),n=e.i(63043),s=e.i(30503),i=e.i(21936),o=e.i(97736);let l=(0,t.pgTable)("vendor_bank_details",{id:(0,r.integer)().primaryKey().generatedAlwaysAsIdentity(),vendorId:(0,r.integer)().notNull().references(()=>o.vendorsTable.id).unique(),accountHolderName:(0,a.varchar)("accountHolderName",{length:255}).notNull(),accountNumber:(0,a.varchar)("accountNumber",{length:50}).notNull(),ifscCode:(0,a.varchar)("ifscCode",{length:11}).notNull(),isPayoutReady:(0,n.boolean)("isPayoutReady").default(!1),isEdited:(0,n.boolean)("isEdited").default(!1),confirmedAt:(0,s.timestamp)("confirmedAt",{withTimezone:!0}),pendingChanges:(0,i.jsonb)("pendingChanges").$type(),adminApprovedAt:(0,s.timestamp)("adminApprovedAt",{withTimezone:!0}),createdAt:(0,s.timestamp)("createdAt",{withTimezone:!0}).defaultNow(),updatedAt:(0,s.timestamp)("updatedAt",{withTimezone:!0}).defaultNow()});e.s(["vendorBankDetailsTable",0,l])},14709,e=>{"use strict";var t=e.i(3745),r=e.i(59145),a=e.i(19643),n=e.i(5896),s=e.i(53795),i=e.i(42009),o=e.i(1654),l=e.i(1630),d=e.i(89727),p=e.i(71366),u=e.i(19441),c=e.i(44235),x=e.i(57281),m=e.i(477),h=e.i(52186),g=e.i(73929),v=e.i(93695);e.i(28633);var f=e.i(18897),b=e.i(83111),y=e.i(67389),R=e.i(85881),w=e.i(19566),E=e.i(50170),A=e.i(97736),T=e.i(54535);async function k(e){var t;let r=e.cookies.get("admin_token")?.value;if(!r)return b.NextResponse.json({error:"Unauthorized"},{status:401});if("admin"!==y.default.verify(r,process.env.JWT_SECRET).role)return b.NextResponse.json({error:"Permission denied"},{status:403});let{vendorId:a}=await e.json();await R.db.update(w.vendorBankDetailsTable).set({pendingChanges:null,isPayoutReady:!1,isEdited:!0}).where((0,E.eq)(w.vendorBankDetailsTable.vendorId,a));let[n]=await R.db.select({email:A.vendorsTable.email,fullName:A.vendorsTable.fullName}).from(A.vendorsTable).where((0,E.eq)(A.vendorsTable.id,a));return await (0,T.sendEmail)({to:n.email,subject:"Bank Details Update Rejected",html:(t=n.fullName,`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;padding:0;margin:0;font-family:Arial,sans-serif;">

    <table width="600" align="center" cellpadding="0" cellspacing="0"
           style="background:white;margin:20px auto;border-radius:12px;
                  border:1px solid #e5e5e5;overflow:hidden;">

      <!-- HEADER -->
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" style="margin-bottom:10px;" />
          <h1 style="margin:0;font-size:26px;color:hsl(222,47%,11%);">
            SR Portraits & Events
          </h1>
        </td>
      </tr>

      <!-- BODY -->
      <tr>
        <td style="padding:35px 40px;text-align:center;">

          <h2 style="margin-bottom:10px;font-size:24px;color:hsl(222,47%,11%);">
            Hi, ${t}
          </h2>

          <p style="font-size:16px;color:#444;margin-bottom:25px;">
            Your recent update to <strong>bank / payout details</strong> has been
            <strong>rejected</strong> by our admin team.
          </p>

          <p style="font-size:15px;color:#666;margin-bottom:25px;">
            This may be due to incorrect information, formatting issues,
            or details that require correction.
          </p>

          <p style="font-size:15px;color:#666;margin-bottom:25px;">
            Until this is resolved, payouts and advance payments will remain
            <strong>temporarily paused</strong>.
          </p>

          <a href="${process.env.DOMAIN}/vendor/profile"
             style="
                display:inline-block;
                padding:16px 36px;
                font-size:16px;
                font-weight:bold;
                color:white;
                text-decoration:none;
                border-radius:9999px;
                background:linear-gradient(135deg, hsl(0, 80%, 55%), hsl(10, 70%, 50%));
                box-shadow:0 8px 32px -8px rgba(0,0,0,0.25);
                margin-top:20px;
             ">
            Review & Resubmit Bank Details
          </a>

          <p style="margin-top:28px;color:#666;font-size:14px;">
            If you believe this was a mistake, feel free to reach out to our support team.
          </p>

        </td>
      </tr>

      <!-- FOOTER -->
      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;color:#777;font-size:12px;">
          &copy; ${new Date().getFullYear()} SR Portraits & Events. All rights reserved.
        </td>
      </tr>

    </table>

  </body>
</html>`)}),b.NextResponse.json({success:!0,message:"Bank details rejected. Vendor must re-submit."})}e.s(["POST",()=>k],84923);var C=e.i(84923);let N=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/admin/vendor-bank-details/reject/route",pathname:"/api/admin/vendor-bank-details/reject",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/admin/vendor-bank-details/reject/route.ts",nextConfigOutput:"",userland:C}),{workAsyncStorage:q,workUnitAsyncStorage:P,serverHooks:j}=N;function O(){return(0,a.patchFetch)({workAsyncStorage:q,workUnitAsyncStorage:P})}async function S(e,t,a){N.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let b="/api/admin/vendor-bank-details/reject/route";b=b.replace(/\/index$/,"")||"/";let y=await N.prepare(e,t,{srcPage:b,multiZoneDraftMode:!1});if(!y)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:R,params:w,nextConfig:E,parsedUrl:A,isDraftMode:T,prerenderManifest:k,routerServerContext:C,isOnDemandRevalidate:q,revalidateOnlyGenerated:P,resolvedPathname:j,clientReferenceManifest:O,serverActionsManifest:S}=y,_=(0,l.normalizeAppPath)(b),D=!!(k.dynamicRoutes[_]||k.routes[j]),I=async()=>((null==C?void 0:C.render404)?await C.render404(e,t,A,!1):t.end("This page could not be found"),null);if(D&&!T){let e=!!k.routes[j],t=k.dynamicRoutes[_];if(t&&!1===t.fallback&&!e){if(E.experimental.adapterPath)return await I();throw new v.NoFallbackError}}let M=null;!D||N.isDev||T||(M="/index"===(M=j)?"/":M);let H=!0===N.isDev||!D,U=D&&!H;S&&O&&(0,i.setReferenceManifestsSingleton)({page:b,clientReferenceManifest:O,serverActionsManifest:S,serverModuleMap:(0,o.createServerModuleMap)({serverActionsManifest:S})});let z=e.method||"GET",$=(0,s.getTracer)(),B=$.getActiveScopeSpan(),F={params:w,prerenderManifest:k,renderOpts:{experimental:{authInterrupts:!!E.experimental.authInterrupts},cacheComponents:!!E.cacheComponents,supportsDynamicResponse:H,incrementalCache:(0,n.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:E.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a)=>N.onRequestError(e,t,a,C)},sharedContext:{buildId:R}},L=new d.NodeNextRequest(e),K=new d.NodeNextResponse(t),G=p.NextRequestAdapter.fromNodeNextRequest(L,(0,p.signalFromNodeResponse)(t));try{let i=async e=>N.handle(G,F).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=$.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${z} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${z} ${b}`)}),o=!!(0,n.getRequestMeta)(e,"minimalMode"),l=async n=>{var s,l;let d=async({previousCacheEntry:r})=>{try{if(!o&&q&&P&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await i(n);e.fetchMetrics=F.renderOpts.fetchMetrics;let l=F.renderOpts.pendingWaitUntil;l&&a.waitUntil&&(a.waitUntil(l),l=void 0);let d=F.renderOpts.collectedTags;if(!D)return await (0,x.sendResponse)(L,K,s,F.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,m.toNodeOutgoingHttpHeaders)(s.headers);d&&(t[g.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==F.renderOpts.collectedRevalidate&&!(F.renderOpts.collectedRevalidate>=g.INFINITE_CACHE)&&F.renderOpts.collectedRevalidate,a=void 0===F.renderOpts.collectedExpire||F.renderOpts.collectedExpire>=g.INFINITE_CACHE?void 0:F.renderOpts.collectedExpire;return{value:{kind:f.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await N.onRequestError(e,t,{routerKind:"App Router",routePath:b,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:q})},C),t}},p=await N.handleResponse({req:e,nextConfig:E,cacheKey:M,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:k,isRoutePPREnabled:!1,isOnDemandRevalidate:q,revalidateOnlyGenerated:P,responseGenerator:d,waitUntil:a.waitUntil,isMinimalMode:o});if(!D)return null;if((null==p||null==(s=p.value)?void 0:s.kind)!==f.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});o||t.setHeader("x-nextjs-cache",q?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),T&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let u=(0,m.fromNodeOutgoingHttpHeaders)(p.value.headers);return o&&D||u.delete(g.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||u.get("Cache-Control")||u.set("Cache-Control",(0,h.getCacheControlHeader)(p.cacheControl)),await (0,x.sendResponse)(L,K,new Response(p.value.body,{headers:u,status:p.value.status||200})),null};B?await l(B):await $.withPropagatedContext(e.headers,()=>$.trace(u.BaseServerSpan.handleRequest,{spanName:`${z} ${b}`,kind:s.SpanKind.SERVER,attributes:{"http.method":z,"http.target":e.url}},l))}catch(t){if(t instanceof v.NoFallbackError||await N.onRequestError(e,t,{routerKind:"App Router",routePath:_,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:q})}),D)throw t;return await (0,x.sendResponse)(L,K,new Response(null,{status:500})),null}}e.s(["handler",()=>S,"patchFetch",()=>O,"routeModule",()=>N,"serverHooks",()=>j,"workAsyncStorage",()=>q,"workUnitAsyncStorage",()=>P],14709)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__5b3d0600._.js.map