module.exports=[85856,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_admin_vendor-bank-details_list_route_actions_c3308588.js.map