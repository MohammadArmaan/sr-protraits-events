module.exports=[37870,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_admin_vendor-cupons_%5Bid%5D_route_actions_83a7a9f2.js.map