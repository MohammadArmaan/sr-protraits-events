module.exports=[53714,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_admin_vendor-products_%5Bid%5D_route_actions_f5874935.js.map