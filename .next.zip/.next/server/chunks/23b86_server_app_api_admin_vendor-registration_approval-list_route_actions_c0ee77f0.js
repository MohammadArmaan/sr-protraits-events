module.exports=[73024,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_admin_vendor-registration_approval-list_route_actions_c0ee77f0.js.map