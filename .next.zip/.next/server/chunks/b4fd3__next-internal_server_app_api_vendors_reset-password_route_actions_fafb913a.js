module.exports=[35852,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_reset-password_route_actions_fafb913a.js.map