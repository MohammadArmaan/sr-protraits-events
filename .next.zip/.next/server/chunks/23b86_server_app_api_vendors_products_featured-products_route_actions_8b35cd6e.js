module.exports=[91749,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_vendors_products_featured-products_route_actions_8b35cd6e.js.map