module.exports=[67975,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_admin_vendor-registration_reject_route_actions_2a59a082.js.map