module.exports=[9976,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_admin_vendor-cupons_route_actions_80b8a601.js.map