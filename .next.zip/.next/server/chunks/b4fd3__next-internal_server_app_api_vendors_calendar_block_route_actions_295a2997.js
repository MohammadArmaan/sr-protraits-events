module.exports=[58052,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_calendar_block_route_actions_295a2997.js.map