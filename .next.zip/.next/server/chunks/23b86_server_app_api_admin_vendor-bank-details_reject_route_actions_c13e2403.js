module.exports=[6905,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_admin_vendor-bank-details_reject_route_actions_c13e2403.js.map