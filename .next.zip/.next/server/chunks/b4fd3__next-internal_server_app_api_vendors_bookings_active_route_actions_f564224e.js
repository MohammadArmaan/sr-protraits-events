module.exports=[63472,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_bookings_active_route_actions_f564224e.js.map