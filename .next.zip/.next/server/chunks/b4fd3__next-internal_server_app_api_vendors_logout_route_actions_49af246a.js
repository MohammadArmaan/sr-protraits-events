module.exports=[35984,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_logout_route_actions_49af246a.js.map