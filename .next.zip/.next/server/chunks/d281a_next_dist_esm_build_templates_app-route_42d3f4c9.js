module.exports=[27220,e=>{"use strict";var t=e.i(3745),r=e.i(59145),n=e.i(19643),o=e.i(5896),a=e.i(53795),s=e.i(42009),i=e.i(1654),d=e.i(1630),l=e.i(89727),u=e.i(71366),c=e.i(19441),p=e.i(44235),v=e.i(57281),m=e.i(477),b=e.i(52186),h=e.i(73929),f=e.i(93695);e.i(28633);var g=e.i(18897),x=e.i(83111),R=e.i(85881),E=e.i(69516),N=e.i(97736),w=e.i(50170),y=e.i(67389),P=e.i(54535),T=e.i(93632),A=e.i(48144);async function C(e,t){try{(0,A.requireAdmin)(e);let{id:r}=await t.params,n=Number(r);if(!Number.isInteger(n))return x.NextResponse.json({error:"Invalid product id"},{status:400});let[o]=await R.db.select().from(E.vendorProductsTable).where((0,w.eq)(E.vendorProductsTable.id,n)).limit(1);if(!o)return x.NextResponse.json({error:"Product not found"},{status:404});return x.NextResponse.json({success:!0,product:o})}catch(e){return console.error("Get Product Error:",e),x.NextResponse.json({error:"Internal server error"},{status:500})}}async function I(e,t){try{var r,n,o;let{id:a}=await t.params,s=Number(a);if(!Number.isInteger(s))return x.NextResponse.json({error:"Invalid product id"},{status:400});let i=e.cookies.get("admin_token")?.value;if(!i)return x.NextResponse.json({error:"Unauthorized"},{status:401});let d=y.default.verify(i,process.env.JWT_SECRET);if(!["admin","superadmin"].includes(d.role))return x.NextResponse.json({error:"Forbidden"},{status:403});let[l]=await R.db.select().from(E.vendorProductsTable).where((0,w.eq)(E.vendorProductsTable.id,s));if(!l)return x.NextResponse.json({error:"Product not found"},{status:404});let[u]=await R.db.select({email:N.vendorsTable.email,businessName:N.vendorsTable.businessName,isApproved:N.vendorsTable.isApproved}).from(N.vendorsTable).where((0,w.eq)(N.vendorsTable.id,l.vendorId));if(!u||!u.isApproved)return x.NextResponse.json({error:"Vendor is not approved"},{status:400});let{title:c,description:p,images:v,featuredImageIndex:m,basePriceSingleDay:b,basePriceMultiDay:h,pricingUnit:f,advanceType:g,advanceValue:T,isFeatured:A,isActive:C}=await e.json(),I=void 0!==b?Number(b):Number(l.basePriceSingleDay),j=void 0!==h?Number(h):Number(l.basePriceMultiDay);if(I<=0||j<=0)return x.NextResponse.json({error:"Prices must be greater than zero"},{status:400});let k=g??l.advanceType,D=null!=T?Number(T):Number(l.advanceValue);if(isNaN(D))return x.NextResponse.json({error:"Advance value must be a valid number"},{status:400});let S=Math.max(I,j);if("PERCENTAGE"===k&&(D<=0||D>100))return x.NextResponse.json({error:"Advance percentage must be between 1 and 100"},{status:400});if("FIXED"===k&&(D<=0||D>=S))return x.NextResponse.json({error:"Fixed advance must be greater than 0 and less than product price"},{status:400});let _=v??l.images;if(!Array.isArray(_)||0===_.length)return x.NextResponse.json({error:"At least one image is required"},{status:400});let O=m??l.featuredImageIndex;if(O<0||O>=_.length)return x.NextResponse.json({error:"Invalid featuredImageIndex"},{status:400});let[q]=await R.db.update(E.vendorProductsTable).set({title:c??l.title,description:void 0!==p?p:l.description,images:_,featuredImageIndex:O,basePriceSingleDay:I.toFixed(2),basePriceMultiDay:j.toFixed(2),pricingUnit:"PER_EVENT"===f?"PER_EVENT":"PER_DAY",advanceType:k,advanceValue:D.toFixed(2),isFeatured:A??l.isFeatured,isActive:C??l.isActive,updatedAt:new Date}).where((0,w.eq)(E.vendorProductsTable.id,s)).returning();return await (0,P.sendEmail)({to:u.email,subject:"Your Product Has Been Updated",html:(r=u.businessName,n=q.title,o=q.uuid,`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;margin:0;font-family:Arial,sans-serif;">
    <table width="600" align="center" style="background:white;margin:20px auto;border-radius:12px;border:1px solid #e5e5e5;">
      
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" />
          <h1 style="color:hsl(222,47%,11%);">SR Portraits & Events</h1>
        </td>
      </tr>

      <tr>
        <td style="padding:35px 40px;text-align:center;">
          <h2>Hi ${r},</h2>

          <p style="font-size:16px;color:#444;">
            Your product <strong>"${n}"</strong> has been
            <strong>updated</strong> by our admin team.
          </p>

          <a href="${process.env.DOMAIN}/vendor/product/${o}"
             style="display:inline-block;padding:16px 36px;
                    color:white;text-decoration:none;border-radius:9999px;
                    background:linear-gradient(135deg, hsl(220, 80%, 55%), hsl(180, 70%, 50%));font-weight:bold;">
            View Updated Product
          </a>

          <p style="margin-top:24px;font-size:14px;color:#666;">
            Please review the changes to ensure everything looks correct.
          </p>
        </td>
      </tr>

      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;font-size:12px;color:#777;">
          \xa9 ${new Date().getFullYear()} SR Portraits & Events
        </td>
      </tr>
    </table>
  </body>
</html>`)}),x.NextResponse.json({success:!0,product:q},{status:200})}catch(e){return console.error("Update Product Error:",e),x.NextResponse.json({error:"Internal server error"},{status:500})}}async function j(e,t){try{var r,n;let{id:o}=await t.params,a=Number(o);if(!Number.isInteger(a))return x.NextResponse.json({error:"Invalid product id"},{status:400});let s=e.cookies.get("admin_token")?.value;if(!s)return x.NextResponse.json({error:"Unauthorized"},{status:401});let i=y.default.verify(s,process.env.JWT_SECRET);if(!["admin","superadmin"].includes(i.role))return x.NextResponse.json({error:"Forbidden"},{status:403});let[d]=await R.db.select({id:E.vendorProductsTable.id,title:E.vendorProductsTable.title,uuid:E.vendorProductsTable.uuid,vendorId:E.vendorProductsTable.vendorId}).from(E.vendorProductsTable).where((0,w.eq)(E.vendorProductsTable.id,a));if(!d)return x.NextResponse.json({error:"Product not found"},{status:404});if((await R.db.select({id:T.vendorBookingsTable.id}).from(T.vendorBookingsTable).where((0,w.and)((0,w.eq)(T.vendorBookingsTable.vendorProductId,a),(0,w.inArray)(T.vendorBookingsTable.status,["REQUESTED","APPROVED","PAYMENT_PENDING","CONFIRMED"]))).limit(1)).length>0)return x.NextResponse.json({error:"Cannot delete product with active or upcoming bookings"},{status:409});let[l]=await R.db.select({email:N.vendorsTable.email,businessName:N.vendorsTable.businessName}).from(N.vendorsTable).where((0,w.eq)(N.vendorsTable.id,d.vendorId));if(!l)return x.NextResponse.json({error:"Vendor not found"},{status:404});return await R.db.delete(E.vendorProductsTable).where((0,w.eq)(E.vendorProductsTable.id,a)),await (0,P.sendEmail)({to:l.email,subject:"Product Removed from Vendor Listing",html:(r=l.businessName,n=d.title,`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;margin:0;font-family:Arial,sans-serif;">
    <table width="600" align="center" style="background:white;margin:20px auto;border-radius:12px;border:1px solid #e5e5e5;">
      
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" />
          <h1>SR Portraits & Events</h1>
        </td>
      </tr>

      <tr>
        <td style="padding:35px 40px;text-align:center;">
          <h2>Hi ${r},</h2>

          <p style="font-size:16px;color:#444;">
            The product <strong>"${n}"</strong> has been
            <strong>removed</strong> from your vendor account.
          </p>

          <p style="font-size:14px;color:#666;">
            If you believe this was done by mistake, please contact our support team.
          </p>
        </td>
      </tr>

      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;font-size:12px;color:#777;">
          \xa9 ${new Date().getFullYear()} SR Portraits & Events
        </td>
      </tr>
    </table>
  </body>
</html>`)}),x.NextResponse.json({success:!0,message:"Product deleted successfully",productId:a},{status:200})}catch(e){return console.error("Safe Delete Product Error:",e),x.NextResponse.json({error:"Internal server error"},{status:500})}}e.s(["DELETE",()=>j,"GET",()=>C,"PUT",()=>I],90928);var k=e.i(90928);let D=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/admin/vendor-products/[id]/route",pathname:"/api/admin/vendor-products/[id]",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/admin/vendor-products/[id]/route.ts",nextConfigOutput:"",userland:k}),{workAsyncStorage:S,workUnitAsyncStorage:_,serverHooks:O}=D;function q(){return(0,n.patchFetch)({workAsyncStorage:S,workUnitAsyncStorage:_})}async function U(e,t,n){D.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let x="/api/admin/vendor-products/[id]/route";x=x.replace(/\/index$/,"")||"/";let R=await D.prepare(e,t,{srcPage:x,multiZoneDraftMode:!1});if(!R)return t.statusCode=400,t.end("Bad Request"),null==n.waitUntil||n.waitUntil.call(n,Promise.resolve()),null;let{buildId:E,params:N,nextConfig:w,parsedUrl:y,isDraftMode:P,prerenderManifest:T,routerServerContext:A,isOnDemandRevalidate:C,revalidateOnlyGenerated:I,resolvedPathname:j,clientReferenceManifest:k,serverActionsManifest:S}=R,_=(0,d.normalizeAppPath)(x),O=!!(T.dynamicRoutes[_]||T.routes[j]),q=async()=>((null==A?void 0:A.render404)?await A.render404(e,t,y,!1):t.end("This page could not be found"),null);if(O&&!P){let e=!!T.routes[j],t=T.dynamicRoutes[_];if(t&&!1===t.fallback&&!e){if(w.experimental.adapterPath)return await q();throw new f.NoFallbackError}}let U=null;!O||D.isDev||P||(U="/index"===(U=j)?"/":U);let M=!0===D.isDev||!O,F=O&&!M;S&&k&&(0,s.setReferenceManifestsSingleton)({page:x,clientReferenceManifest:k,serverActionsManifest:S,serverModuleMap:(0,i.createServerModuleMap)({serverActionsManifest:S})});let H=e.method||"GET",$=(0,a.getTracer)(),V=$.getActiveScopeSpan(),z={params:N,prerenderManifest:T,renderOpts:{experimental:{authInterrupts:!!w.experimental.authInterrupts},cacheComponents:!!w.cacheComponents,supportsDynamicResponse:M,incrementalCache:(0,o.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:w.cacheLife,waitUntil:n.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,n)=>D.onRequestError(e,t,n,A)},sharedContext:{buildId:E}},B=new l.NodeNextRequest(e),K=new l.NodeNextResponse(t),Y=u.NextRequestAdapter.fromNodeNextRequest(B,(0,u.signalFromNodeResponse)(t));try{let s=async e=>D.handle(Y,z).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=$.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=r.get("next.route");if(n){let t=`${H} ${n}`;e.setAttributes({"next.route":n,"http.route":n,"next.span_name":t}),e.updateName(t)}else e.updateName(`${H} ${x}`)}),i=!!(0,o.getRequestMeta)(e,"minimalMode"),d=async o=>{var a,d;let l=async({previousCacheEntry:r})=>{try{if(!i&&C&&I&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let a=await s(o);e.fetchMetrics=z.renderOpts.fetchMetrics;let d=z.renderOpts.pendingWaitUntil;d&&n.waitUntil&&(n.waitUntil(d),d=void 0);let l=z.renderOpts.collectedTags;if(!O)return await (0,v.sendResponse)(B,K,a,z.renderOpts.pendingWaitUntil),null;{let e=await a.blob(),t=(0,m.toNodeOutgoingHttpHeaders)(a.headers);l&&(t[h.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==z.renderOpts.collectedRevalidate&&!(z.renderOpts.collectedRevalidate>=h.INFINITE_CACHE)&&z.renderOpts.collectedRevalidate,n=void 0===z.renderOpts.collectedExpire||z.renderOpts.collectedExpire>=h.INFINITE_CACHE?void 0:z.renderOpts.collectedExpire;return{value:{kind:g.CachedRouteKind.APP_ROUTE,status:a.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:n}}}}catch(t){throw(null==r?void 0:r.isStale)&&await D.onRequestError(e,t,{routerKind:"App Router",routePath:x,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:F,isOnDemandRevalidate:C})},A),t}},u=await D.handleResponse({req:e,nextConfig:w,cacheKey:U,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:T,isRoutePPREnabled:!1,isOnDemandRevalidate:C,revalidateOnlyGenerated:I,responseGenerator:l,waitUntil:n.waitUntil,isMinimalMode:i});if(!O)return null;if((null==u||null==(a=u.value)?void 0:a.kind)!==g.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(d=u.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",C?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),P&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,m.fromNodeOutgoingHttpHeaders)(u.value.headers);return i&&O||c.delete(h.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,b.getCacheControlHeader)(u.cacheControl)),await (0,v.sendResponse)(B,K,new Response(u.value.body,{headers:c,status:u.value.status||200})),null};V?await d(V):await $.withPropagatedContext(e.headers,()=>$.trace(c.BaseServerSpan.handleRequest,{spanName:`${H} ${x}`,kind:a.SpanKind.SERVER,attributes:{"http.method":H,"http.target":e.url}},d))}catch(t){if(t instanceof f.NoFallbackError||await D.onRequestError(e,t,{routerKind:"App Router",routePath:_,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:F,isOnDemandRevalidate:C})}),O)throw t;return await (0,v.sendResponse)(B,K,new Response(null,{status:500})),null}}e.s(["handler",()=>U,"patchFetch",()=>q,"routeModule",()=>D,"serverHooks",()=>O,"workAsyncStorage",()=>S,"workUnitAsyncStorage",()=>_],27220)}];

//# sourceMappingURL=d281a_next_dist_esm_build_templates_app-route_42d3f4c9.js.map