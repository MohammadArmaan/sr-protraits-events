module.exports=[56892,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_vendors_bookings_%5Buuid%5D_notes_route_actions_c4293cb5.js.map