module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},24361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},88947,(e,t,r)=>{t.exports=e.x("stream",()=>require("stream"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},27699,(e,t,r)=>{t.exports=e.x("events",()=>require("events"))},92509,(e,t,r)=>{t.exports=e.x("url",()=>require("url"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},21517,(e,t,r)=>{t.exports=e.x("http",()=>require("http"))},24836,(e,t,r)=>{t.exports=e.x("https",()=>require("https"))},6461,(e,t,r)=>{t.exports=e.x("zlib",()=>require("zlib"))},46786,(e,t,r)=>{t.exports=e.x("os",()=>require("os"))},54535,e=>{"use strict";var t=e.i(60914);async function r({to:e,subject:r,html:s,attachments:o}){try{let n=t.default.createTransport({service:"gmail",auth:{user:process.env.GMAIL_EMAIL,pass:process.env.GMAIL_APP_PASSWORD}});return await n.sendMail({from:`SR Portraits & Events <${process.env.GMAIL_EMAIL}>`,to:e,subject:r,html:s,attachments:o}),{success:!0}}catch(e){return console.error("Email Send Error:",e),{success:!1,error:e}}}e.s(["sendEmail",()=>r])},59485,(e,t,r)=>{t.exports=e.x("@aws-sdk/client-s3",()=>require("@aws-sdk/client-s3"))},93302,e=>{"use strict";var t=e.i(3745),r=e.i(59145),s=e.i(19643),o=e.i(5896),n=e.i(53795),a=e.i(42009),i=e.i(1654),l=e.i(1630),d=e.i(89727),p=e.i(71366),u=e.i(19441),c=e.i(44235),x=e.i(57281),h=e.i(477),f=e.i(52186),v=e.i(73929),m=e.i(93695);e.i(28633);var g=e.i(18897),b=e.i(83111),R=e.i(85881),w=e.i(51559),E=e.i(97736),y=e.i(50170),P=e.i(67389),A=e.i(59485),C=e.i(54535);let N=new A.S3Client({region:process.env.AWS_REGION,credentials:{accessKeyId:process.env.AWS_ACCESS_KEY,secretAccessKey:process.env.AWS_SECRET_ACCESS}});async function q(e){try{var t;let r=e.cookies.get("admin_token")?.value;if(!r)return b.NextResponse.json({error:"Unauthorized"},{status:401});let s=P.default.verify(r,process.env.JWT_SECRET);if("admin"!==s.role)return b.NextResponse.json({error:"Permission denied"},{status:403});let{editId:o}=await e.json(),[n]=await R.db.select().from(w.vendorProfileEdits).where((0,y.eq)(w.vendorProfileEdits.id,o));if(!n)return b.NextResponse.json({error:"Edit request not found"},{status:404});if("PENDING"!==n.status)return b.NextResponse.json({error:"Request already processed"},{status:400});let[a]=await R.db.select().from(E.vendorsTable).where((0,y.eq)(E.vendorsTable.id,n.vendorId));if(!a)return b.NextResponse.json({error:"Vendor not found"},{status:404});let i=n.changes??{},l={...i};n.newProfilePhotoUrl&&(l.profilePhoto=n.newProfilePhotoUrl),Array.isArray(i.businessPhotos)&&(l.businessPhotos=i.businessPhotos);let d={};if(l.fullName&&(d.fullName=l.fullName),l.businessName&&(d.businessName=l.businessName),l.occupation&&(d.occupation=l.occupation),l.phone&&(d.phone=l.phone),l.address&&(d.address=l.address),l.businessDescription&&(d.businessDescription=l.businessDescription),l.profilePhoto&&(d.profilePhoto=l.profilePhoto),l.businessPhotos&&(d.businessPhotos=l.businessPhotos),0===Object.keys(d).length)return b.NextResponse.json({success:!0,message:"No changes to apply"},{status:200});if(await R.db.update(E.vendorsTable).set(d).where((0,y.eq)(E.vendorsTable.id,a.id)),n.newProfilePhotoUrl&&n.oldProfilePhotoUrl){let e=n.oldProfilePhotoUrl.split(".com/")[1];e&&await N.send(new A.DeleteObjectCommand({Bucket:process.env.AWS_S3_BUCKET_NAME,Key:e}))}return await R.db.update(w.vendorProfileEdits).set({status:"APPROVED",approvedByAdminId:s.adminId,reviewedAt:new Date}).where((0,y.eq)(w.vendorProfileEdits.id,o)),await (0,C.sendEmail)({to:a.email,subject:"Your Profile is Updated",html:(t=a.fullName,`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;padding:0;margin:0;font-family:Arial,sans-serif;">

    <table width="600" align="center" cellpadding="0" cellspacing="0"
           style="background:white;margin:20px auto;border-radius:12px;
                  border:1px solid #e5e5e5;overflow:hidden;">

      <!-- HEADER -->
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" style="margin-bottom:10px;" />
          <h1 style="margin:0;font-size:26px;color:hsl(222,47%,11%);">
            SR Portraits & Events
          </h1>
        </td>
      </tr>

      <!-- BODY -->
      <tr>
        <td style="padding:35px 40px;text-align:center;">

          <h2 style="margin-bottom:10px;font-size:24px;color:hsl(222,47%,11%);">
            Hi, ${t} 🎉
          </h2>

          <p style="font-size:16px;color:#444;margin-bottom:25px;">
            Great news! Your vendor profile update request has been <strong>approved</strong> 
            by our admin team.<br /><br />
            The updated details are now live on your public vendor profile.
          </p>

          <a href="${process.env.DOMAIN}/vendor/profile"
             style="
                display:inline-block;
                padding:16px 36px;
                font-size:16px;
                font-weight:bold;
                color:white;
                text-decoration:none;
                border-radius:9999px;
                background:linear-gradient(135deg, hsl(220, 80%, 55%), hsl(180, 70%, 50%));
                box-shadow:0 8px 32px -8px rgba(0,0,0,0.25);
                margin-top:20px;
             ">
            View Updated Profile
          </a>

          <p style="margin-top:28px;color:#666;font-size:14px;">
            If you did not request this change, please contact support immediately.
          </p>

        </td>
      </tr>

      <!-- FOOTER -->
      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;color:#777;font-size:12px;">
          &copy; ${new Date().getFullYear()} SR Portraits & Events. All rights reserved.
        </td>
      </tr>

    </table>

  </body>
</html>`)}),b.NextResponse.json({success:!0,message:"Profile edit approved successfully"},{status:200})}catch(e){return console.error("Approve Error:",e),b.NextResponse.json({error:"Server error approving request"},{status:500})}}e.s(["POST",()=>q],51274);var S=e.i(51274);let T=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/admin/profile-edits/approve/route",pathname:"/api/admin/profile-edits/approve",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/admin/profile-edits/approve/route.ts",nextConfigOutput:"",userland:S}),{workAsyncStorage:_,workUnitAsyncStorage:k,serverHooks:O}=T;function j(){return(0,s.patchFetch)({workAsyncStorage:_,workUnitAsyncStorage:k})}async function I(e,t,s){T.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let b="/api/admin/profile-edits/approve/route";b=b.replace(/\/index$/,"")||"/";let R=await T.prepare(e,t,{srcPage:b,multiZoneDraftMode:!1});if(!R)return t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve()),null;let{buildId:w,params:E,nextConfig:y,parsedUrl:P,isDraftMode:A,prerenderManifest:C,routerServerContext:N,isOnDemandRevalidate:q,revalidateOnlyGenerated:S,resolvedPathname:_,clientReferenceManifest:k,serverActionsManifest:O}=R,j=(0,l.normalizeAppPath)(b),I=!!(C.dynamicRoutes[j]||C.routes[_]),D=async()=>((null==N?void 0:N.render404)?await N.render404(e,t,P,!1):t.end("This page could not be found"),null);if(I&&!A){let e=!!C.routes[_],t=C.dynamicRoutes[j];if(t&&!1===t.fallback&&!e){if(y.experimental.adapterPath)return await D();throw new m.NoFallbackError}}let U=null;!I||T.isDev||A||(U="/index"===(U=_)?"/":U);let M=!0===T.isDev||!I,H=I&&!M;O&&k&&(0,a.setReferenceManifestsSingleton)({page:b,clientReferenceManifest:k,serverActionsManifest:O,serverModuleMap:(0,i.createServerModuleMap)({serverActionsManifest:O})});let K=e.method||"GET",$=(0,n.getTracer)(),z=$.getActiveScopeSpan(),F={params:E,prerenderManifest:C,renderOpts:{experimental:{authInterrupts:!!y.experimental.authInterrupts},cacheComponents:!!y.cacheComponents,supportsDynamicResponse:M,incrementalCache:(0,o.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:y.cacheLife,waitUntil:s.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,s)=>T.onRequestError(e,t,s,N)},sharedContext:{buildId:w}},L=new d.NodeNextRequest(e),B=new d.NodeNextResponse(t),G=p.NextRequestAdapter.fromNodeNextRequest(L,(0,p.signalFromNodeResponse)(t));try{let a=async e=>T.handle(G,F).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=$.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=r.get("next.route");if(s){let t=`${K} ${s}`;e.setAttributes({"next.route":s,"http.route":s,"next.span_name":t}),e.updateName(t)}else e.updateName(`${K} ${b}`)}),i=!!(0,o.getRequestMeta)(e,"minimalMode"),l=async o=>{var n,l;let d=async({previousCacheEntry:r})=>{try{if(!i&&q&&S&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let n=await a(o);e.fetchMetrics=F.renderOpts.fetchMetrics;let l=F.renderOpts.pendingWaitUntil;l&&s.waitUntil&&(s.waitUntil(l),l=void 0);let d=F.renderOpts.collectedTags;if(!I)return await (0,x.sendResponse)(L,B,n,F.renderOpts.pendingWaitUntil),null;{let e=await n.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(n.headers);d&&(t[v.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==F.renderOpts.collectedRevalidate&&!(F.renderOpts.collectedRevalidate>=v.INFINITE_CACHE)&&F.renderOpts.collectedRevalidate,s=void 0===F.renderOpts.collectedExpire||F.renderOpts.collectedExpire>=v.INFINITE_CACHE?void 0:F.renderOpts.collectedExpire;return{value:{kind:g.CachedRouteKind.APP_ROUTE,status:n.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:s}}}}catch(t){throw(null==r?void 0:r.isStale)&&await T.onRequestError(e,t,{routerKind:"App Router",routePath:b,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:q})},N),t}},p=await T.handleResponse({req:e,nextConfig:y,cacheKey:U,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:C,isRoutePPREnabled:!1,isOnDemandRevalidate:q,revalidateOnlyGenerated:S,responseGenerator:d,waitUntil:s.waitUntil,isMinimalMode:i});if(!I)return null;if((null==p||null==(n=p.value)?void 0:n.kind)!==g.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",q?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),A&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let u=(0,h.fromNodeOutgoingHttpHeaders)(p.value.headers);return i&&I||u.delete(v.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||u.get("Cache-Control")||u.set("Cache-Control",(0,f.getCacheControlHeader)(p.cacheControl)),await (0,x.sendResponse)(L,B,new Response(p.value.body,{headers:u,status:p.value.status||200})),null};z?await l(z):await $.withPropagatedContext(e.headers,()=>$.trace(u.BaseServerSpan.handleRequest,{spanName:`${K} ${b}`,kind:n.SpanKind.SERVER,attributes:{"http.method":K,"http.target":e.url}},l))}catch(t){if(t instanceof m.NoFallbackError||await T.onRequestError(e,t,{routerKind:"App Router",routePath:j,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:q})}),I)throw t;return await (0,x.sendResponse)(L,B,new Response(null,{status:500})),null}}e.s(["handler",()=>I,"patchFetch",()=>j,"routeModule",()=>T,"serverHooks",()=>O,"workAsyncStorage",()=>_,"workUnitAsyncStorage",()=>k],93302)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__2d944573._.js.map