module.exports=[85625,e=>{"use strict";var t=e.i(3745),r=e.i(59145),n=e.i(19643),o=e.i(5896),a=e.i(53795),s=e.i(42009),i=e.i(1654),l=e.i(1630),d=e.i(89727),u=e.i(71366),p=e.i(19441),c=e.i(44235),h=e.i(57281),g=e.i(477),v=e.i(52186),f=e.i(73929),m=e.i(93695);e.i(28633);var b=e.i(18897),x=e.i(83111),R=e.i(67389),w=e.i(85881),E=e.i(69516),y=e.i(93632),T=e.i(50170),N=e.i(53693),A=e.i(54535),C=e.i(97736);let P=e=>e.toISOString().slice(0,10);async function k(e){try{var t,r,n,o,a,s;let i,l=e.cookies.get("vendor_token")?.value;if(!l)return x.NextResponse.json({error:"Unauthorized"},{status:401});try{i=R.default.verify(l,process.env.JWT_SECRET)}catch{return x.NextResponse.json({error:"Invalid token"},{status:401})}let{vendorProductId:d,startDate:u,endDate:p,startTime:c,endTime:h,couponCode:g,notes:v}=await e.json();if(!d||!u)return x.NextResponse.json({error:"vendorProductId and startDate are required"},{status:400});let[f]=await w.db.select().from(E.vendorProductsTable).where((0,T.and)((0,T.eq)(E.vendorProductsTable.id,d),(0,T.eq)(E.vendorProductsTable.isActive,!0)));if(!f)return x.NextResponse.json({error:"Product not found"},{status:404});if(f.vendorId===i.vendorId)return x.NextResponse.json({error:"You cannot book your own service"},{status:403});let m=new Date(u),b=p?new Date(p):m;if(b<m)return x.NextResponse.json({error:"End date cannot be before start date"},{status:400});let k=p&&b>m?"MULTI_DAY":"SINGLE_DAY",D="MULTI_DAY"===k?Math.floor((b.getTime()-m.getTime())/864e5)+1:1,I="MULTI_DAY"===k?Number(f.basePriceMultiDay):Number(f.basePriceSingleDay),S="MULTI_DAY"===k?I*D:I,q=0,M=null;if(g){let[e]=await w.db.select().from(N.couponCodesTable).where((0,T.and)((0,T.eq)(N.couponCodesTable.code,g.toUpperCase()),(0,T.eq)(N.couponCodesTable.isActive,!0)));if(!e)return x.NextResponse.json({error:"Invalid or inactive coupon code"},{status:400});let t=new Date;if(e.expiresAt&&e.expiresAt<t)return x.NextResponse.json({error:"Coupon has expired"},{status:400});if(e.minAmount&&S<Number(e.minAmount))return x.NextResponse.json({error:`Minimum order amount ₹${e.minAmount} required for this coupon`},{status:400});if("FLAT"===e.type&&(q=Number(e.value)),"PERCENT"===e.type&&(q=Math.round(S*Number(e.value)/100)),"UPTO"===e.type){let t=Math.round(S*Number(e.value)/100);q=e.maxDiscount?Math.min(t,Number(e.maxDiscount)):t}if((q=Math.min(q,S))<=0)return x.NextResponse.json({error:"Coupon not applicable"},{status:400});M=e.code}let _=S-q,O=0;"PERCENTAGE"===f.advanceType&&(O=Math.round(_*Number(f.advanceValue)/100)),"FIXED"===f.advanceType&&(O=Number(f.advanceValue)),O=Math.max(0,Math.min(O,_));let j=_-O,[U]=await w.db.select({email:C.vendorsTable.email,businessName:C.vendorsTable.businessName}).from(C.vendorsTable).where((0,T.eq)(C.vendorsTable.id,f.vendorId));if(!U)return x.NextResponse.json({error:"Vendor not found"},{status:404});let[H]=await w.db.select({id:C.vendorsTable.id,email:C.vendorsTable.email,fullName:C.vendorsTable.fullName}).from(C.vendorsTable).where((0,T.eq)(C.vendorsTable.id,i.vendorId));if(!H)return x.NextResponse.json({error:"User not found"},{status:404});let $={vendorId:f.vendorId,vendorProductId:f.id,bookedByVendorId:H.id,bookingType:k,startDate:P(m),endDate:P(b),startTime:"SINGLE_DAY"===k?c:null,endTime:"SINGLE_DAY"===k?h:null,basePrice:I.toFixed(2),totalDays:D,totalAmount:S.toFixed(2),couponCode:M??null,discountAmount:q.toFixed(2),finalAmount:_.toFixed(2),advanceAmount:O.toFixed(2),remainingAmount:j.toFixed(2),status:"REQUESTED",approvalExpiresAt:new Date(Date.now()+108e5),notes:v??null,source:"WEB"},[F]=await w.db.insert(y.vendorBookingsTable).values($).returning();return await (0,A.sendEmail)({to:U.email,subject:"New Booking Request – Action Required ⏳",html:(t=U.businessName,r=f.title,n=F.uuid,o=F.approvalExpiresAt,`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;margin:0;font-family:Arial,sans-serif;">
    <table width="600" align="center" style="background:white;margin:20px auto;border-radius:12px;border:1px solid #e5e5e5;">
      
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" />
          <h1 style="margin:10px 0 0;color:hsl(222,47%,11%);">
            SR Portraits & Events
          </h1>
        </td>
      </tr>

      <tr>
        <td style="padding:35px 40px;text-align:center;">
          <h2>Hi ${t} 👋</h2>

          <p style="font-size:16px;color:#444;">
            You have received a new booking request for
            <strong>"${r}"</strong>.
          </p>

          <p style="font-size:15px;color:#555;">
            Please approve or reject this request within
            <strong>3 hours</strong>.
          </p>

          <a href="${process.env.DOMAIN}/vendor/bookings/${n}"
             style="display:inline-block;padding:16px 36px;color:white;
                    text-decoration:none;border-radius:9999px;
                    background:linear-gradient(135deg, hsl(220, 80%, 55%), hsl(180, 70%, 50%));
                    font-weight:bold;margin-top:20px;">
            Review Booking
          </a>

          <p style="margin-top:18px;font-size:13px;color:#777;">
            Approval expires at:
            <strong>${o.toLocaleString()}</strong>
          </p>
        </td>
      </tr>

      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;font-size:12px;color:#777;">
          \xa9 ${new Date().getFullYear()} SR Portraits & Events
        </td>
      </tr>
    </table>
  </body>
</html>`)}),await (0,A.sendEmail)({to:H.email,subject:"Booking Request Sent Successfully ✅",html:(a=H.fullName,s=f.title,`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;margin:0;font-family:Arial,sans-serif;">
    <table width="600" align="center" style="background:white;margin:20px auto;border-radius:12px;border:1px solid #e5e5e5;">
      
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" />
          <h1>SR Portraits & Events</h1>
        </td>
      </tr>

      <tr>
        <td style="padding:35px 40px;text-align:center;">
          <h2>Hello ${a} 🎉</h2>

          <p style="font-size:16px;color:#444;">
            Your booking request for
            <strong>"${s}"</strong>
            has been successfully sent.
          </p>

          <p style="font-size:14px;color:#666;">
            The vendor has up to <strong>3 hours</strong> to approve your request.
          </p>
        </td>
      </tr>

      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;font-size:12px;color:#777;">
          \xa9 ${new Date().getFullYear()} SR Portraits & Events
        </td>
      </tr>
    </table>
  </body>
</html>`)}),x.NextResponse.json({success:!0,message:"Booking request sent",booking:F},{status:201})}catch(e){return console.error("Booking Request Error:",e),x.NextResponse.json({error:"Internal server error"},{status:500})}}e.s(["POST",()=>k],96653);var D=e.i(96653);let I=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/vendors/bookings/request/route",pathname:"/api/vendors/bookings/request",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/vendors/bookings/request/route.ts",nextConfigOutput:"",userland:D}),{workAsyncStorage:S,workUnitAsyncStorage:q,serverHooks:M}=I;function _(){return(0,n.patchFetch)({workAsyncStorage:S,workUnitAsyncStorage:q})}async function O(e,t,n){I.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let x="/api/vendors/bookings/request/route";x=x.replace(/\/index$/,"")||"/";let R=await I.prepare(e,t,{srcPage:x,multiZoneDraftMode:!1});if(!R)return t.statusCode=400,t.end("Bad Request"),null==n.waitUntil||n.waitUntil.call(n,Promise.resolve()),null;let{buildId:w,params:E,nextConfig:y,parsedUrl:T,isDraftMode:N,prerenderManifest:A,routerServerContext:C,isOnDemandRevalidate:P,revalidateOnlyGenerated:k,resolvedPathname:D,clientReferenceManifest:S,serverActionsManifest:q}=R,M=(0,l.normalizeAppPath)(x),_=!!(A.dynamicRoutes[M]||A.routes[D]),O=async()=>((null==C?void 0:C.render404)?await C.render404(e,t,T,!1):t.end("This page could not be found"),null);if(_&&!N){let e=!!A.routes[D],t=A.dynamicRoutes[M];if(t&&!1===t.fallback&&!e){if(y.experimental.adapterPath)return await O();throw new m.NoFallbackError}}let j=null;!_||I.isDev||N||(j="/index"===(j=D)?"/":j);let U=!0===I.isDev||!_,H=_&&!U;q&&S&&(0,s.setReferenceManifestsSingleton)({page:x,clientReferenceManifest:S,serverActionsManifest:q,serverModuleMap:(0,i.createServerModuleMap)({serverActionsManifest:q})});let $=e.method||"GET",F=(0,a.getTracer)(),L=F.getActiveScopeSpan(),Y={params:E,prerenderManifest:A,renderOpts:{experimental:{authInterrupts:!!y.experimental.authInterrupts},cacheComponents:!!y.cacheComponents,supportsDynamicResponse:U,incrementalCache:(0,o.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:y.cacheLife,waitUntil:n.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,n)=>I.onRequestError(e,t,n,C)},sharedContext:{buildId:w}},B=new d.NodeNextRequest(e),z=new d.NodeNextResponse(t),K=u.NextRequestAdapter.fromNodeNextRequest(B,(0,u.signalFromNodeResponse)(t));try{let s=async e=>I.handle(K,Y).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=F.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=r.get("next.route");if(n){let t=`${$} ${n}`;e.setAttributes({"next.route":n,"http.route":n,"next.span_name":t}),e.updateName(t)}else e.updateName(`${$} ${x}`)}),i=!!(0,o.getRequestMeta)(e,"minimalMode"),l=async o=>{var a,l;let d=async({previousCacheEntry:r})=>{try{if(!i&&P&&k&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let a=await s(o);e.fetchMetrics=Y.renderOpts.fetchMetrics;let l=Y.renderOpts.pendingWaitUntil;l&&n.waitUntil&&(n.waitUntil(l),l=void 0);let d=Y.renderOpts.collectedTags;if(!_)return await (0,h.sendResponse)(B,z,a,Y.renderOpts.pendingWaitUntil),null;{let e=await a.blob(),t=(0,g.toNodeOutgoingHttpHeaders)(a.headers);d&&(t[f.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==Y.renderOpts.collectedRevalidate&&!(Y.renderOpts.collectedRevalidate>=f.INFINITE_CACHE)&&Y.renderOpts.collectedRevalidate,n=void 0===Y.renderOpts.collectedExpire||Y.renderOpts.collectedExpire>=f.INFINITE_CACHE?void 0:Y.renderOpts.collectedExpire;return{value:{kind:b.CachedRouteKind.APP_ROUTE,status:a.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:n}}}}catch(t){throw(null==r?void 0:r.isStale)&&await I.onRequestError(e,t,{routerKind:"App Router",routePath:x,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:P})},C),t}},u=await I.handleResponse({req:e,nextConfig:y,cacheKey:j,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:A,isRoutePPREnabled:!1,isOnDemandRevalidate:P,revalidateOnlyGenerated:k,responseGenerator:d,waitUntil:n.waitUntil,isMinimalMode:i});if(!_)return null;if((null==u||null==(a=u.value)?void 0:a.kind)!==b.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(l=u.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",P?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),N&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let p=(0,g.fromNodeOutgoingHttpHeaders)(u.value.headers);return i&&_||p.delete(f.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||t.getHeader("Cache-Control")||p.get("Cache-Control")||p.set("Cache-Control",(0,v.getCacheControlHeader)(u.cacheControl)),await (0,h.sendResponse)(B,z,new Response(u.value.body,{headers:p,status:u.value.status||200})),null};L?await l(L):await F.withPropagatedContext(e.headers,()=>F.trace(p.BaseServerSpan.handleRequest,{spanName:`${$} ${x}`,kind:a.SpanKind.SERVER,attributes:{"http.method":$,"http.target":e.url}},l))}catch(t){if(t instanceof m.NoFallbackError||await I.onRequestError(e,t,{routerKind:"App Router",routePath:M,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:P})}),_)throw t;return await (0,h.sendResponse)(B,z,new Response(null,{status:500})),null}}e.s(["handler",()=>O,"patchFetch",()=>_,"routeModule",()=>I,"serverHooks",()=>M,"workAsyncStorage",()=>S,"workUnitAsyncStorage",()=>q],85625)}];

//# sourceMappingURL=d281a_next_dist_esm_build_templates_app-route_47752151.js.map