module.exports=[48454,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_send-email_route_actions_a8768457.js.map