module.exports=[41390,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_bank-details_route_actions_d969701e.js.map