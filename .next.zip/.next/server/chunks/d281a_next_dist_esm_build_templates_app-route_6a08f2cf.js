module.exports=[61318,e=>{"use strict";var t=e.i(3745),r=e.i(59145),a=e.i(19643),i=e.i(5896),n=e.i(53795),o=e.i(42009),s=e.i(1654),l=e.i(1630),d=e.i(89727),p=e.i(71366),c=e.i(19441),u=e.i(44235),g=e.i(57281),h=e.i(477),f=e.i(52186),x=e.i(73929),m=e.i(93695);e.i(28633);var v=e.i(18897),b=e.i(83111),y=e.i(97736),w=e.i(85881),R=e.i(98687),E=e.i(67389),C=e.i(50170),A=e.i(54535);async function N(e){try{let{fullName:t,businessName:r,occupation:a,phone:i,address:n,email:o,password:s,confirmPassword:l}=await e.json();if(!t||!r||!a||!i||!n||!o||!s||!l)return b.NextResponse.json({error:"All fields are required"},{status:400});if(s!==l)return b.NextResponse.json({error:"Passwords do not match"},{status:400});if((await w.db.select().from(y.vendorsTable).where((0,C.eq)(y.vendorsTable.email,o))).length>0)return b.NextResponse.json({error:"Email already registered"},{status:400});let d=await R.default.hash(s,10),p=Math.floor(1e5+9e5*Math.random()).toString(),c=new Date(Date.now()+6e5),u=(await w.db.insert(y.vendorsTable).values({fullName:t,businessName:r,occupation:a,phone:i,address:n,email:o,passwordHash:d,emailVerified:!1,emailVerificationOtp:p,emailVerificationExpires:c,currentStep:1,status:"PENDING_EMAIL_VERIFICATION"}).returning())[0].id,g=E.default.sign({vendorId:u,step:1},process.env.JWT_SECRET,{expiresIn:"2h"});return await (0,A.sendEmail)({to:o,subject:"Your SR Portraits & Events Verification Code",html:`<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body style="background:#f5f7fa;padding:0;margin:0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f7fa;padding:40px 0;">
      <tr>
        <td align="center">
          <table width="600" cellpadding="0" cellspacing="0" style="background:white;border-radius:16px;box-shadow:0 4px 24px rgba(0,0,0,0.08);overflow:hidden;">
            
            <!-- Header with Gradient -->
            <tr>
              <td style="padding:0;background:linear-gradient(135deg, hsl(220, 80%, 55%), hsl(180, 70%, 50%));text-align:center;">
                <table width="100%" cellpadding="0" cellspacing="0">
                  <tr>
                    <td style="padding:40px 40px 35px;">
                      <div style="background:rgba(255,255,255,0.15);backdrop-filter:blur(10px);border-radius:12px;padding:20px;display:inline-block;border:1px solid rgba(255,255,255,0.2);">
                        <img src="/logo.webp" width="80" style="display:block;" alt="SR Portraits & Events Logo" />
                      </div>
                      <h1 style="margin:20px 0 0;font-size:28px;color:white;font-weight:600;letter-spacing:-0.5px;">
                        SR Portraits & Events
                      </h1>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

            <!-- Main Content -->
            <tr>
              <td style="padding:45px 50px;">
                <h2 style="margin:0 0 12px;font-size:24px;color:#1a1a1a;font-weight:600;letter-spacing:-0.3px;">
                  Verify Your Email Address
                </h2>
                <p style="font-size:15px;color:#6b7280;line-height:1.6;margin:0 0 35px;">
                  We've sent you this code to verify your email address. Enter the code below to complete your registration.
                </p>

                <!-- OTP Container -->
                <div style="background:linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);border-radius:12px;padding:35px;margin-bottom:35px;border:2px dashed #e2e8f0;">
                  <p style="font-size:13px;color:#64748b;margin:0 0 20px;text-transform:uppercase;letter-spacing:1px;font-weight:600;">
                    Your Verification Code
                  </p>
                  
                  <!-- OTP Digits -->
                  <table align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      ${p.split("").map((e,t)=>`
                        <td style="padding:0 6px;">
                          <div style="
                            width:55px;
                            height:65px;
                            background:linear-gradient(135deg, hsl(220, 80%, 55%), hsl(180, 70%, 50%));
                            color:white;
                            font-size:32px;
                            font-weight:700;
                            border-radius:12px;
                            display:flex;
                            align-items:center;
                            justify-content:center;
                            box-shadow:0 4px 12px rgba(59, 130, 246, 0.3);
                            letter-spacing:0;
                            font-family:Consolas,Monaco,'Courier New',monospace;
                          ">
                            <table width="100%" height="100%" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="middle" style="color:white;font-size:32px;font-weight:700;">
                                  ${e}
                                </td>
                              </tr>
                            </table>
                          </div>
                        </td>`).join("")}
                    </tr>
                  </table>
                  
                  <p style="margin:25px 0 0;color:#64748b;font-size:13px;text-align:center;">
                    <strong style="color:#334155;">Expires in 10 minutes</strong>
                  </p>
                </div>

                <!-- Security Notice -->
                <div style="background:#fef3c7;border-left:4px solid #f59e0b;padding:16px 20px;border-radius:8px;margin-bottom:30px;">
                  <p style="margin:0;font-size:14px;color:#92400e;line-height:1.5;">
                    <strong style="display:block;margin-bottom:4px;">🔒 Security Tip</strong>
                    Never share this code with anyone. SR Portraits & Events will never ask for your verification code.
                  </p>
                </div>

                <!-- Alternative Action -->
                <p style="font-size:14px;color:#6b7280;line-height:1.6;margin:0;text-align:center;">
                  Didn't request this code? You can safely ignore this email.
                </p>
              </td>
            </tr>

            <!-- Divider -->
            <tr>
              <td style="padding:0 50px;">
                <div style="height:1px;background:linear-gradient(to right, transparent, #e2e8f0, transparent);"></div>
              </td>
            </tr>

            <!-- Footer -->
            <tr>
              <td style="padding:30px 50px;">
                <table width="100%" cellpadding="0" cellspacing="0">
                  <tr>
                    <td style="text-align:center;">
                      <p style="margin:0 0 15px;color:#9ca3af;font-size:13px;">
                        Need help? Contact our support team
                      </p>
                      <p style="margin:0 0 20px;">
                        <a href="mailto:support@srportraits.com" style="color:#3b82f6;text-decoration:none;font-size:14px;font-weight:500;">
                          support@srportraits.com
                        </a>
                      </p>
                      <div style="border-top:1px solid #e5e7eb;padding-top:20px;margin-top:10px;">
                        <p style="margin:0;color:#9ca3af;font-size:12px;line-height:1.6;">
                          \xa9 ${new Date().getFullYear()} SR Portraits & Events. All rights reserved.<br>
                          <span style="color:#d1d5db;">Professional Photography & Event Management Services</span>
                        </p>
                      </div>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>

          </table>
        </td>
      </tr>
    </table>
  </body>
</html>`}),b.NextResponse.json({success:!0,message:"Vendor registered. OTP sent to email.",vendorId:u,onboardingToken:g},{status:201})}catch(e){return console.error("Vendor Registration Error:",e),b.NextResponse.json({error:"Internal server error"},{status:500})}}e.s(["POST",()=>N],67419);var P=e.i(67419);let T=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/vendors/register/route",pathname:"/api/vendors/register",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/vendors/register/route.ts",nextConfigOutput:"",userland:P}),{workAsyncStorage:S,workUnitAsyncStorage:k,serverHooks:O}=T;function I(){return(0,a.patchFetch)({workAsyncStorage:S,workUnitAsyncStorage:k})}async function M(e,t,a){T.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let b="/api/vendors/register/route";b=b.replace(/\/index$/,"")||"/";let y=await T.prepare(e,t,{srcPage:b,multiZoneDraftMode:!1});if(!y)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:w,params:R,nextConfig:E,parsedUrl:C,isDraftMode:A,prerenderManifest:N,routerServerContext:P,isOnDemandRevalidate:S,revalidateOnlyGenerated:k,resolvedPathname:O,clientReferenceManifest:I,serverActionsManifest:M}=y,_=(0,l.normalizeAppPath)(b),D=!!(N.dynamicRoutes[_]||N.routes[O]),H=async()=>((null==P?void 0:P.render404)?await P.render404(e,t,C,!1):t.end("This page could not be found"),null);if(D&&!A){let e=!!N.routes[O],t=N.dynamicRoutes[_];if(t&&!1===t.fallback&&!e){if(E.experimental.adapterPath)return await H();throw new m.NoFallbackError}}let U=null;!D||T.isDev||A||(U="/index"===(U=O)?"/":U);let j=!0===T.isDev||!D,q=D&&!j;M&&I&&(0,o.setReferenceManifestsSingleton)({page:b,clientReferenceManifest:I,serverActionsManifest:M,serverModuleMap:(0,s.createServerModuleMap)({serverActionsManifest:M})});let z=e.method||"GET",F=(0,n.getTracer)(),V=F.getActiveScopeSpan(),$={params:R,prerenderManifest:N,renderOpts:{experimental:{authInterrupts:!!E.experimental.authInterrupts},cacheComponents:!!E.cacheComponents,supportsDynamicResponse:j,incrementalCache:(0,i.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:E.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a)=>T.onRequestError(e,t,a,P)},sharedContext:{buildId:w}},K=new d.NodeNextRequest(e),L=new d.NodeNextResponse(t),B=p.NextRequestAdapter.fromNodeNextRequest(K,(0,p.signalFromNodeResponse)(t));try{let o=async e=>T.handle(B,$).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=F.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${z} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${z} ${b}`)}),s=!!(0,i.getRequestMeta)(e,"minimalMode"),l=async i=>{var n,l;let d=async({previousCacheEntry:r})=>{try{if(!s&&S&&k&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let n=await o(i);e.fetchMetrics=$.renderOpts.fetchMetrics;let l=$.renderOpts.pendingWaitUntil;l&&a.waitUntil&&(a.waitUntil(l),l=void 0);let d=$.renderOpts.collectedTags;if(!D)return await (0,g.sendResponse)(K,L,n,$.renderOpts.pendingWaitUntil),null;{let e=await n.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(n.headers);d&&(t[x.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==$.renderOpts.collectedRevalidate&&!($.renderOpts.collectedRevalidate>=x.INFINITE_CACHE)&&$.renderOpts.collectedRevalidate,a=void 0===$.renderOpts.collectedExpire||$.renderOpts.collectedExpire>=x.INFINITE_CACHE?void 0:$.renderOpts.collectedExpire;return{value:{kind:v.CachedRouteKind.APP_ROUTE,status:n.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await T.onRequestError(e,t,{routerKind:"App Router",routePath:b,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:q,isOnDemandRevalidate:S})},P),t}},p=await T.handleResponse({req:e,nextConfig:E,cacheKey:U,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:N,isRoutePPREnabled:!1,isOnDemandRevalidate:S,revalidateOnlyGenerated:k,responseGenerator:d,waitUntil:a.waitUntil,isMinimalMode:s});if(!D)return null;if((null==p||null==(n=p.value)?void 0:n.kind)!==v.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});s||t.setHeader("x-nextjs-cache",S?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),A&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,h.fromNodeOutgoingHttpHeaders)(p.value.headers);return s&&D||c.delete(x.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,f.getCacheControlHeader)(p.cacheControl)),await (0,g.sendResponse)(K,L,new Response(p.value.body,{headers:c,status:p.value.status||200})),null};V?await l(V):await F.withPropagatedContext(e.headers,()=>F.trace(c.BaseServerSpan.handleRequest,{spanName:`${z} ${b}`,kind:n.SpanKind.SERVER,attributes:{"http.method":z,"http.target":e.url}},l))}catch(t){if(t instanceof m.NoFallbackError||await T.onRequestError(e,t,{routerKind:"App Router",routePath:_,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:q,isOnDemandRevalidate:S})}),D)throw t;return await (0,g.sendResponse)(K,L,new Response(null,{status:500})),null}}e.s(["handler",()=>M,"patchFetch",()=>I,"routeModule",()=>T,"serverHooks",()=>O,"workAsyncStorage",()=>S,"workUnitAsyncStorage",()=>k],61318)}];

//# sourceMappingURL=d281a_next_dist_esm_build_templates_app-route_6a08f2cf.js.map