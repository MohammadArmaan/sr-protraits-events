module.exports=[86709,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_vendors_calendar_block_%5Buuid%5D_route_actions_2a23f338.js.map