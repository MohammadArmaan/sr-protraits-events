module.exports=[67556,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_forgot-password_route_actions_1d0f62ff.js.map