module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},24361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},88947,(e,t,r)=>{t.exports=e.x("stream",()=>require("stream"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},27699,(e,t,r)=>{t.exports=e.x("events",()=>require("events"))},92509,(e,t,r)=>{t.exports=e.x("url",()=>require("url"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},21517,(e,t,r)=>{t.exports=e.x("http",()=>require("http"))},24836,(e,t,r)=>{t.exports=e.x("https",()=>require("https"))},6461,(e,t,r)=>{t.exports=e.x("zlib",()=>require("zlib"))},46786,(e,t,r)=>{t.exports=e.x("os",()=>require("os"))},54535,e=>{"use strict";var t=e.i(60914);async function r({to:e,subject:r,html:s,attachments:a}){try{let n=t.default.createTransport({service:"gmail",auth:{user:process.env.GMAIL_EMAIL,pass:process.env.GMAIL_APP_PASSWORD}});return await n.sendMail({from:`SR Portraits & Events <${process.env.GMAIL_EMAIL}>`,to:e,subject:r,html:s,attachments:a}),{success:!0}}catch(e){return console.error("Email Send Error:",e),{success:!1,error:e}}}e.s(["sendEmail",()=>r])},70919,e=>{"use strict";var t=e.i(3745),r=e.i(59145),s=e.i(19643),a=e.i(5896),n=e.i(53795),o=e.i(42009),i=e.i(1654),l=e.i(1630),d=e.i(89727),p=e.i(71366),u=e.i(19441),c=e.i(44235),x=e.i(57281),h=e.i(477),g=e.i(52186),f=e.i(73929),v=e.i(93695);e.i(28633);var m=e.i(18897),w=e.i(83111),R=e.i(85881),b=e.i(97736),y=e.i(50170),E=e.i(54799),A=e.i(54535);async function q(e){try{var t;let{email:r}=await e.json();if(!r)return w.NextResponse.json({error:"Email is required"},{status:400});let s=await R.db.select().from(b.vendorsTable).where((0,y.eq)(b.vendorsTable.email,r));if(0===s.length)return w.NextResponse.json({message:"If an account exists, a reset email will be sent."},{status:200});let a=s[0],n=E.default.randomBytes(32).toString("hex"),o=new Date(Date.now()+6e5);await R.db.update(b.vendorsTable).set({resetPasswordToken:n,resetPasswordExpires:o}).where((0,y.eq)(b.vendorsTable.id,a.id));let i=`/vendor/password-reset?token=${n}`;return await (0,A.sendEmail)({to:a.email,subject:"Reset Your Password",html:(t=a.fullName,`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;padding:0;margin:0;font-family:Arial,sans-serif;">

    <table width="600" align="center" cellpadding="0" cellspacing="0"
           style="background:white;margin:20px auto;border-radius:12px;
                  border:1px solid #e5e5e5;overflow:hidden;">

      <!-- HEADER -->
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" style="margin-bottom:10px;" />
          <h1 style="margin:0;font-size:26px;color:hsl(222,47%,11%);">
            SR Portraits & Events
          </h1>
        </td>
      </tr>

      <!-- BODY -->
      <tr>
        <td style="padding:35px 40px;text-align:center;">

          <h2 style="margin-bottom:10px;font-size:24px;color:hsl(222,47%,11%);">
            Password Reset Request
          </h2>

          <p style="font-size:16px;color:#444;margin-bottom:25px;">
            Hello ${t},<br />
            We received a request to reset your password.  
            Click the button below to create a new one.
          </p>

          <!-- RESET BUTTON -->
          <a href="${process.env.DOMAIN}${i}"
             style="
                display:inline-block;
                padding:16px 36px;
                font-size:16px;
                font-weight:bold;
                color:white;
                text-decoration:none;
                border-radius:9999px;
                background:linear-gradient(135deg, hsl(220,80%,55%), hsl(180,70%,50%));
                box-shadow:0 8px 32px -8px rgba(0,0,0,0.25);
                margin-top:20px;
             ">
            Reset My Password
          </a>

          <p style="margin-top:28px;color:#666;font-size:14px;">
            This link expires in <strong>10 minutes</strong>.<br />
            If you didn’t request this, simply ignore this email.
          </p>

        </td>
      </tr>

      <!-- FOOTER -->
      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;color:#777;font-size:12px;">
          &copy; ${new Date().getFullYear()} SR Portraits & Events. All rights reserved.
        </td>
      </tr>

    </table>

  </body>
</html>
`)}),w.NextResponse.json({success:!0,message:"If an account exists, reset email has been sent."},{status:200})}catch(e){return console.error("Forgot password error:",e),w.NextResponse.json({error:"Server error"},{status:500})}}e.s(["POST",()=>q],48769);var C=e.i(48769);let T=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/vendors/forgot-password/route",pathname:"/api/vendors/forgot-password",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/vendors/forgot-password/route.ts",nextConfigOutput:"",userland:C}),{workAsyncStorage:P,workUnitAsyncStorage:k,serverHooks:N}=T;function S(){return(0,s.patchFetch)({workAsyncStorage:P,workUnitAsyncStorage:k})}async function O(e,t,s){T.isDev&&(0,a.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let w="/api/vendors/forgot-password/route";w=w.replace(/\/index$/,"")||"/";let R=await T.prepare(e,t,{srcPage:w,multiZoneDraftMode:!1});if(!R)return t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve()),null;let{buildId:b,params:y,nextConfig:E,parsedUrl:A,isDraftMode:q,prerenderManifest:C,routerServerContext:P,isOnDemandRevalidate:k,revalidateOnlyGenerated:N,resolvedPathname:S,clientReferenceManifest:O,serverActionsManifest:j}=R,I=(0,l.normalizeAppPath)(w),M=!!(C.dynamicRoutes[I]||C.routes[S]),_=async()=>((null==P?void 0:P.render404)?await P.render404(e,t,A,!1):t.end("This page could not be found"),null);if(M&&!q){let e=!!C.routes[S],t=C.dynamicRoutes[I];if(t&&!1===t.fallback&&!e){if(E.experimental.adapterPath)return await _();throw new v.NoFallbackError}}let D=null;!M||T.isDev||q||(D="/index"===(D=S)?"/":D);let H=!0===T.isDev||!M,U=M&&!H;j&&O&&(0,o.setReferenceManifestsSingleton)({page:w,clientReferenceManifest:O,serverActionsManifest:j,serverModuleMap:(0,i.createServerModuleMap)({serverActionsManifest:j})});let $=e.method||"GET",F=(0,n.getTracer)(),L=F.getActiveScopeSpan(),z={params:y,prerenderManifest:C,renderOpts:{experimental:{authInterrupts:!!E.experimental.authInterrupts},cacheComponents:!!E.cacheComponents,supportsDynamicResponse:H,incrementalCache:(0,a.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:E.cacheLife,waitUntil:s.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,s)=>T.onRequestError(e,t,s,P)},sharedContext:{buildId:b}},B=new d.NodeNextRequest(e),K=new d.NodeNextResponse(t),G=p.NextRequestAdapter.fromNodeNextRequest(B,(0,p.signalFromNodeResponse)(t));try{let o=async e=>T.handle(G,z).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=F.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=r.get("next.route");if(s){let t=`${$} ${s}`;e.setAttributes({"next.route":s,"http.route":s,"next.span_name":t}),e.updateName(t)}else e.updateName(`${$} ${w}`)}),i=!!(0,a.getRequestMeta)(e,"minimalMode"),l=async a=>{var n,l;let d=async({previousCacheEntry:r})=>{try{if(!i&&k&&N&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let n=await o(a);e.fetchMetrics=z.renderOpts.fetchMetrics;let l=z.renderOpts.pendingWaitUntil;l&&s.waitUntil&&(s.waitUntil(l),l=void 0);let d=z.renderOpts.collectedTags;if(!M)return await (0,x.sendResponse)(B,K,n,z.renderOpts.pendingWaitUntil),null;{let e=await n.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(n.headers);d&&(t[f.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==z.renderOpts.collectedRevalidate&&!(z.renderOpts.collectedRevalidate>=f.INFINITE_CACHE)&&z.renderOpts.collectedRevalidate,s=void 0===z.renderOpts.collectedExpire||z.renderOpts.collectedExpire>=f.INFINITE_CACHE?void 0:z.renderOpts.collectedExpire;return{value:{kind:m.CachedRouteKind.APP_ROUTE,status:n.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:s}}}}catch(t){throw(null==r?void 0:r.isStale)&&await T.onRequestError(e,t,{routerKind:"App Router",routePath:w,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:k})},P),t}},p=await T.handleResponse({req:e,nextConfig:E,cacheKey:D,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:C,isRoutePPREnabled:!1,isOnDemandRevalidate:k,revalidateOnlyGenerated:N,responseGenerator:d,waitUntil:s.waitUntil,isMinimalMode:i});if(!M)return null;if((null==p||null==(n=p.value)?void 0:n.kind)!==m.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",k?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),q&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let u=(0,h.fromNodeOutgoingHttpHeaders)(p.value.headers);return i&&M||u.delete(f.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||u.get("Cache-Control")||u.set("Cache-Control",(0,g.getCacheControlHeader)(p.cacheControl)),await (0,x.sendResponse)(B,K,new Response(p.value.body,{headers:u,status:p.value.status||200})),null};L?await l(L):await F.withPropagatedContext(e.headers,()=>F.trace(u.BaseServerSpan.handleRequest,{spanName:`${$} ${w}`,kind:n.SpanKind.SERVER,attributes:{"http.method":$,"http.target":e.url}},l))}catch(t){if(t instanceof v.NoFallbackError||await T.onRequestError(e,t,{routerKind:"App Router",routePath:I,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:k})}),M)throw t;return await (0,x.sendResponse)(B,K,new Response(null,{status:500})),null}}e.s(["handler",()=>O,"patchFetch",()=>S,"routeModule",()=>T,"serverHooks",()=>N,"workAsyncStorage",()=>P,"workUnitAsyncStorage",()=>k],70919)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__51e8475a._.js.map