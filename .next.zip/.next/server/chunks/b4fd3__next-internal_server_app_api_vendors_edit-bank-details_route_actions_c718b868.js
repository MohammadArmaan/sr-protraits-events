module.exports=[42879,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_edit-bank-details_route_actions_c718b868.js.map