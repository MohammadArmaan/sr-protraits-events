module.exports=[74696,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_admin_vendor-cupons_list_route_actions_a65a7cdf.js.map