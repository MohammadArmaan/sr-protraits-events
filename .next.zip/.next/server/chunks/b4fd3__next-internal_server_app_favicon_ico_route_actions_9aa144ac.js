module.exports=[14352,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_favicon_ico_route_actions_9aa144ac.js.map