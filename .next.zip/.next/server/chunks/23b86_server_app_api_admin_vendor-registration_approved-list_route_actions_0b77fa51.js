module.exports=[21504,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_admin_vendor-registration_approved-list_route_actions_0b77fa51.js.map