module.exports=[63479,(e,o,d)=>{}];

//# sourceMappingURL=6aa0a_next-internal_server_app_api_admin_profile-edits_approve_route_actions_7ea15ead.js.map