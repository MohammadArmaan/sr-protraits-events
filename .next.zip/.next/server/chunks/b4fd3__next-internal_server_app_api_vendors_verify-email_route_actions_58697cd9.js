module.exports=[52656,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_verify-email_route_actions_58697cd9.js.map