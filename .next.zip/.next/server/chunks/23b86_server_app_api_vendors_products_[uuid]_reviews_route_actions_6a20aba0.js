module.exports=[55482,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_vendors_products_%5Buuid%5D_reviews_route_actions_6a20aba0.js.map