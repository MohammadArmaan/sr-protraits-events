module.exports=[52015,e=>{"use strict";function t(e,t,a){return`
<!DOCTYPE html>
<html>
<body style="background:#f4f4f4;margin:0;font-family:Arial,sans-serif;">
<table width="600" align="center" style="background:white;margin:20px auto;border-radius:12px;">
<tr>
<td style="padding:30px;text-align:center;">
<h2>Booking Confirmed 🎉</h2>

<p>Hello ${e},</p>

<p>
Your booking has been <strong>successfully confirmed</strong>.
The service provider <strong>${t}</strong> has been notified.
</p>

<a href="${process.env.DOMAIN}/vendor/calendar"
   style="display:inline-block;padding:14px 32px;
          background:linear-gradient(135deg, hsl(220, 80%, 55%), hsl(180, 70%, 50%));
          color:white;text-decoration:none;border-radius:9999px;">
View Calendar
</a>

<p style="margin-top:16px;font-size:14px;color:#666;">
Your invoice is attached with this email.
</p>

</td>
</tr>
</table>
</body>
</html>`}e.s(["bookingConfirmedRequesterTemplate",()=>t])},43159,e=>{"use strict";function t(e,t){return`
<!DOCTYPE html>
<html>
<body style="background:#f4f4f4;margin:0;font-family:Arial,sans-serif;">
<table width="600" align="center" style="background:white;margin:20px auto;border-radius:12px;">
<tr>
<td style="padding:30px;text-align:center;">
<h2>New Booking Confirmed ✅</h2>

<p>Hello ${e},</p>

<p>
Your service has been booked by <strong>${t}</strong>.
</p>

<p>
Please check your calendar for upcoming events.
</p>

<a href="${process.env.DOMAIN}/vendor/calendar"
   style="display:inline-block;padding:14px 32px;
          background:linear-gradient(135deg, hsl(220, 80%, 55%), hsl(180, 70%, 50%));
          color:white;text-decoration:none;border-radius:9999px;">
Open Calendar
</a>

</td>
</tr>
</table>
</body>
</html>`}e.s(["bookingConfirmedProviderTemplate",()=>t])},3595,e=>e.a(async(t,a)=>{try{var n=e.i(83111),r=e.i(54799),o=e.i(85881),i=e.i(50170),s=e.i(11187),d=e.i(93632),l=e.i(97736),u=e.i(69516),p=e.i(54535),c=e.i(69334),h=e.i(1022),m=e.i(52015),b=e.i(43159),f=t([h]);async function v(e){try{let{razorpay_order_id:t,razorpay_payment_id:a,razorpay_signature:f}=await e.json();if(r.default.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET).update(t+"|"+a).digest("hex")!==f)return n.NextResponse.json({error:"Invalid signature"},{status:400});let[v]=await o.db.update(s.vendorPaymentsTable).set({razorpayPaymentId:a,razorpaySignature:f,status:"PAID",updatedAt:new Date}).where((0,i.eq)(s.vendorPaymentsTable.razorpayOrderId,t)).returning();if(!v)return n.NextResponse.json({error:"Payment not found"},{status:404});let[g]=await o.db.select().from(d.vendorBookingsTable).where((0,i.eq)(d.vendorBookingsTable.paymentId,v.id));if(!g)return n.NextResponse.json({error:"Booking not found"},{status:404});await o.db.update(d.vendorBookingsTable).set({status:"CONFIRMED",updatedAt:new Date}).where((0,i.eq)(d.vendorBookingsTable.id,g.id));let y=v.amount/100,R=Number(g.finalAmount),w=Math.max(R-y,0),[[T],[x]]=await Promise.all([o.db.select({businessName:l.vendorsTable.businessName,email:l.vendorsTable.email,phone:l.vendorsTable.phone,address:l.vendorsTable.address,profilePhoto:l.vendorsTable.profilePhoto}).from(l.vendorsTable).where((0,i.eq)(l.vendorsTable.id,g.bookedByVendorId)),o.db.select({businessName:l.vendorsTable.businessName,email:l.vendorsTable.email,phone:l.vendorsTable.phone,address:l.vendorsTable.address,profilePhoto:l.vendorsTable.profilePhoto}).from(l.vendorsTable).where((0,i.eq)(l.vendorsTable.id,g.vendorId))]),[P]=await o.db.select({title:u.vendorProductsTable.title}).from(u.vendorProductsTable).where((0,i.eq)(u.vendorProductsTable.id,g.vendorProductId)),C={name:T.businessName,email:T.email,phone:T.phone,address:T.address,profilePhoto:T.profilePhoto},E={name:x.businessName,email:x.email,phone:x.phone,address:x.address,profilePhoto:x.profilePhoto},N=(0,c.vendorInvoiceTemplate)({invoiceNumber:g.uuid,bookingDate:new Date().toLocaleDateString(),productTitle:P.title,bookingType:g.bookingType,startDate:g.startDate,endDate:g.endDate,totalDays:g.totalDays,basePrice:Number(g.totalAmount),discountAmount:Number(g.discountAmount),finalAmount:R,advanceAmount:y,remainingAmount:w,requester:C,provider:E}),k=await (0,h.generateInvoicePdf)(N);return await (0,p.sendEmail)({to:T.email,subject:"Invoice & Booking Confirmed 🧾",html:(0,m.bookingConfirmedRequesterTemplate)(T.businessName,x.businessName,g.uuid),attachments:[{filename:`Invoice-${g.uuid}.pdf`,content:k,contentType:"application/pdf"}]}),await (0,p.sendEmail)({to:x.email,subject:"New Booking Confirmed 📅",html:(0,b.bookingConfirmedProviderTemplate)(x.businessName,T.businessName),attachments:[{filename:`Invoice-${g.uuid}.pdf`,content:k,contentType:"application/pdf"}]}),n.NextResponse.json({success:!0})}catch(e){return console.error("Verify payment error:",e),n.NextResponse.json({error:"Payment verification failed"},{status:500})}}[h]=f.then?(await f)():f,e.s(["POST",()=>v]),a()}catch(e){a(e)}},!1),96290,e=>e.a(async(t,a)=>{try{var n=e.i(3745),r=e.i(59145),o=e.i(19643),i=e.i(5896),s=e.i(53795),d=e.i(42009),l=e.i(1654),u=e.i(1630),p=e.i(89727),c=e.i(71366),h=e.i(19441),m=e.i(44235),b=e.i(57281),f=e.i(477),v=e.i(52186),g=e.i(73929),y=e.i(93695);e.i(28633);var R=e.i(18897),w=e.i(3595),T=t([w]);[w]=T.then?(await T)():T;let C=new n.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/vendors/bookings/payment/verify/route",pathname:"/api/vendors/bookings/payment/verify",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/vendors/bookings/payment/verify/route.ts",nextConfigOutput:"",userland:w}),{workAsyncStorage:E,workUnitAsyncStorage:N,serverHooks:k}=C;function x(){return(0,o.patchFetch)({workAsyncStorage:E,workUnitAsyncStorage:N})}async function P(e,t,a){C.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/vendors/bookings/payment/verify/route";n=n.replace(/\/index$/,"")||"/";let o=await C.prepare(e,t,{srcPage:n,multiZoneDraftMode:!1});if(!o)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:w,params:T,nextConfig:x,parsedUrl:P,isDraftMode:E,prerenderManifest:N,routerServerContext:k,isOnDemandRevalidate:A,revalidateOnlyGenerated:D,resolvedPathname:I,clientReferenceManifest:O,serverActionsManifest:S}=o,q=(0,u.normalizeAppPath)(n),_=!!(N.dynamicRoutes[q]||N.routes[I]),H=async()=>((null==k?void 0:k.render404)?await k.render404(e,t,P,!1):t.end("This page could not be found"),null);if(_&&!E){let e=!!N.routes[I],t=N.dynamicRoutes[q];if(t&&!1===t.fallback&&!e){if(x.experimental.adapterPath)return await H();throw new y.NoFallbackError}}let M=null;!_||C.isDev||E||(M=I,M="/index"===M?"/":M);let $=!0===C.isDev||!_,j=_&&!$;S&&O&&(0,d.setReferenceManifestsSingleton)({page:n,clientReferenceManifest:O,serverActionsManifest:S,serverModuleMap:(0,l.createServerModuleMap)({serverActionsManifest:S})});let U=e.method||"GET",B=(0,s.getTracer)(),F=B.getActiveScopeSpan(),K={params:T,prerenderManifest:N,renderOpts:{experimental:{authInterrupts:!!x.experimental.authInterrupts},cacheComponents:!!x.cacheComponents,supportsDynamicResponse:$,incrementalCache:(0,i.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:x.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,n)=>C.onRequestError(e,t,n,k)},sharedContext:{buildId:w}},Y=new p.NodeNextRequest(e),L=new p.NodeNextResponse(t),V=c.NextRequestAdapter.fromNodeNextRequest(Y,(0,c.signalFromNodeResponse)(t));try{let o=async e=>C.handle(V,K).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=B.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==h.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${U} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t)}else e.updateName(`${U} ${n}`)}),d=!!(0,i.getRequestMeta)(e,"minimalMode"),l=async i=>{var s,l;let u=async({previousCacheEntry:r})=>{try{if(!d&&A&&D&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let n=await o(i);e.fetchMetrics=K.renderOpts.fetchMetrics;let s=K.renderOpts.pendingWaitUntil;s&&a.waitUntil&&(a.waitUntil(s),s=void 0);let l=K.renderOpts.collectedTags;if(!_)return await (0,b.sendResponse)(Y,L,n,K.renderOpts.pendingWaitUntil),null;{let e=await n.blob(),t=(0,f.toNodeOutgoingHttpHeaders)(n.headers);l&&(t[g.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==K.renderOpts.collectedRevalidate&&!(K.renderOpts.collectedRevalidate>=g.INFINITE_CACHE)&&K.renderOpts.collectedRevalidate,r=void 0===K.renderOpts.collectedExpire||K.renderOpts.collectedExpire>=g.INFINITE_CACHE?void 0:K.renderOpts.collectedExpire;return{value:{kind:R.CachedRouteKind.APP_ROUTE,status:n.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==r?void 0:r.isStale)&&await C.onRequestError(e,t,{routerKind:"App Router",routePath:n,routeType:"route",revalidateReason:(0,m.getRevalidateReason)({isStaticGeneration:j,isOnDemandRevalidate:A})},k),t}},p=await C.handleResponse({req:e,nextConfig:x,cacheKey:M,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:N,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:D,responseGenerator:u,waitUntil:a.waitUntil,isMinimalMode:d});if(!_)return null;if((null==p||null==(s=p.value)?void 0:s.kind)!==R.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});d||t.setHeader("x-nextjs-cache",A?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),E&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,f.fromNodeOutgoingHttpHeaders)(p.value.headers);return d&&_||c.delete(g.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,v.getCacheControlHeader)(p.cacheControl)),await (0,b.sendResponse)(Y,L,new Response(p.value.body,{headers:c,status:p.value.status||200})),null};F?await l(F):await B.withPropagatedContext(e.headers,()=>B.trace(h.BaseServerSpan.handleRequest,{spanName:`${U} ${n}`,kind:s.SpanKind.SERVER,attributes:{"http.method":U,"http.target":e.url}},l))}catch(t){if(t instanceof y.NoFallbackError||await C.onRequestError(e,t,{routerKind:"App Router",routePath:q,routeType:"route",revalidateReason:(0,m.getRevalidateReason)({isStaticGeneration:j,isOnDemandRevalidate:A})}),_)throw t;return await (0,b.sendResponse)(Y,L,new Response(null,{status:500})),null}}e.s(["handler",()=>P,"patchFetch",()=>x,"routeModule",()=>C,"serverHooks",()=>k,"workAsyncStorage",()=>E,"workUnitAsyncStorage",()=>N]),a()}catch(e){a(e)}},!1)];

//# sourceMappingURL=Documents_Nextjs_sr-portriats-events_2e880a71._.js.map