module.exports=[90993,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_coupons_validate_route_actions_b471ab9f.js.map