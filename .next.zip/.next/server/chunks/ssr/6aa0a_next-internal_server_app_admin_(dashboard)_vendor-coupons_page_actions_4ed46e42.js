module.exports=[5603,(a,b,c)=>{}];

//# sourceMappingURL=6aa0a_next-internal_server_app_admin_%28dashboard%29_vendor-coupons_page_actions_4ed46e42.js.map