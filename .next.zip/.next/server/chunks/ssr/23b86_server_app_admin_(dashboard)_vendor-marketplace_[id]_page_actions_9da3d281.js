module.exports=[67506,(a,b,c)=>{}];

//# sourceMappingURL=23b86_server_app_admin_%28dashboard%29_vendor-marketplace_%5Bid%5D_page_actions_9da3d281.js.map