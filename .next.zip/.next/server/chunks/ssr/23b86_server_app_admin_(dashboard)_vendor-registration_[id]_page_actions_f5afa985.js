module.exports=[14830,(a,b,c)=>{}];

//# sourceMappingURL=23b86_server_app_admin_%28dashboard%29_vendor-registration_%5Bid%5D_page_actions_f5afa985.js.map