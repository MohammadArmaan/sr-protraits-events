module.exports=[54442,(a,b,c)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_admin_%28auth%29_login_page_actions_c062022b.js.map