module.exports=[81634,(a,b,c)=>{}];

//# sourceMappingURL=6aa0a_next-internal_server_app_admin_%28dashboard%29_vendor-banners_page_actions_a84c26af.js.map