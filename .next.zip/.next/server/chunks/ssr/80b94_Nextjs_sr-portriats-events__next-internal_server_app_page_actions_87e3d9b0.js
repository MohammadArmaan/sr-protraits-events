module.exports=[61607,(a,b,c)=>{}];

//# sourceMappingURL=80b94_Nextjs_sr-portriats-events__next-internal_server_app_page_actions_87e3d9b0.js.map