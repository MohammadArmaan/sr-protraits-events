module.exports=[70269,(a,b,c)=>{}];

//# sourceMappingURL=23b86_server_app_admin_%28dashboard%29_vendor-registration_page_actions_23281bd8.js.map