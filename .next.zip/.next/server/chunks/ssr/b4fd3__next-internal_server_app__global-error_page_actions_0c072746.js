module.exports=[63807,(a,b,c)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app__global-error_page_actions_0c072746.js.map