module.exports=[74675,(a,b,c)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_vendor_%28vendor-protected%29_shop_page_actions_d9a35d0d.js.map