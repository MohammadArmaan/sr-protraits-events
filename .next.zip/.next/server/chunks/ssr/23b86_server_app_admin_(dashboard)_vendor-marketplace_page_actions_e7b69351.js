module.exports=[1798,(a,b,c)=>{}];

//# sourceMappingURL=23b86_server_app_admin_%28dashboard%29_vendor-marketplace_page_actions_e7b69351.js.map