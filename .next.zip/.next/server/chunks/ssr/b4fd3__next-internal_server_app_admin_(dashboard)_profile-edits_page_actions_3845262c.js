module.exports=[70580,(a,b,c)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_admin_%28dashboard%29_profile-edits_page_actions_3845262c.js.map