module.exports=[21350,a=>{a.v("/_next/static/media/favicon.69b6b5ee.ico")},85202,a=>{"use strict";let b={src:a.i(21350).default,width:64,height:64};a.s(["default",0,b])}];

//# sourceMappingURL=Documents_Nextjs_sr-portriats-events_src_app_3dcb5c26._.js.map