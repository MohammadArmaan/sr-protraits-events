module.exports=[37416,(a,b,c)=>{}];

//# sourceMappingURL=23b86_server_app_admin_%28dashboard%29_vendor-bank-details_page_actions_fd74e534.js.map