module.exports=[77642,(a,b,c)=>{}];

//# sourceMappingURL=23b86_server_app_admin_%28dashboard%29_vendor-marketplace_new_page_actions_673c2724.js.map