module.exports=[78070,(a,b,c)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_vendor_%28auth%29_password-reset_page_actions_54d08562.js.map