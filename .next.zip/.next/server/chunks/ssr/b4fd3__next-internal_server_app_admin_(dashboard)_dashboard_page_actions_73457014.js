module.exports=[92244,(a,b,c)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_admin_%28dashboard%29_dashboard_page_actions_73457014.js.map