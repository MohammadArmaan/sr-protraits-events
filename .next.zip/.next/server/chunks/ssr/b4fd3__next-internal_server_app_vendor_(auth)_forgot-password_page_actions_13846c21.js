module.exports=[74107,(a,b,c)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_vendor_%28auth%29_forgot-password_page_actions_13846c21.js.map