module.exports=[70239,(a,b,c)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_vendor_%28auth%29_register_page_actions_bc84a0c4.js.map