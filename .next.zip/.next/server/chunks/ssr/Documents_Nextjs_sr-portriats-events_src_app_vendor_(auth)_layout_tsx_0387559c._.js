module.exports=[32919,a=>{"use strict";var b=a.i(58298);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=Documents_Nextjs_sr-portriats-events_src_app_vendor_%28auth%29_layout_tsx_0387559c._.js.map