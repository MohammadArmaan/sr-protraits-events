module.exports=[24425,(a,b,c)=>{}];

//# sourceMappingURL=23b86_server_app_admin_%28dashboard%29_vendor-marketplace_%5Bid%5D_edit_page_actions_83b8786a.js.map