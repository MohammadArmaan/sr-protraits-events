module.exports=[9018,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_activate_route_actions_f6e46deb.js.map