module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},24361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},88947,(e,t,r)=>{t.exports=e.x("stream",()=>require("stream"))},93632,e=>{"use strict";var t=e.i(71920),r=e.i(79559),n=e.i(28500),a=e.i(30503),o=e.i(44579),i=e.i(40408),s=e.i(18018),d=e.i(71145),l=e.i(97736),u=e.i(69516),p=e.i(11187);let c=(0,t.pgTable)("vendor_bookings",{id:(0,r.integer)().primaryKey().generatedAlwaysAsIdentity(),uuid:(0,d.uuid)("uuid").defaultRandom().notNull().unique(),vendorId:(0,r.integer)().notNull().references(()=>l.vendorsTable.id),bookedByVendorId:(0,r.integer)().notNull().references(()=>l.vendorsTable.id),vendorProductId:(0,r.integer)().notNull().references(()=>u.vendorProductsTable.id),paymentId:(0,r.integer)().references(()=>p.vendorPaymentsTable.id),bookingType:(0,n.varchar)("bookingType",{length:20}).notNull(),startDate:(0,o.date)("startDate").notNull(),endDate:(0,o.date)("endDate").notNull(),startTime:(0,i.time)("startTime"),endTime:(0,i.time)("endTime"),basePrice:(0,s.numeric)("basePrice",{precision:10,scale:2}).notNull(),totalDays:(0,r.integer)("totalDays").notNull(),totalAmount:(0,s.numeric)("totalAmount",{precision:10,scale:2}).notNull(),couponCode:(0,n.varchar)("couponCode",{length:50}),discountAmount:(0,s.numeric)("discountAmount",{precision:10,scale:2}).default("0"),finalAmount:(0,s.numeric)("finalAmount",{precision:10,scale:2}).notNull(),advanceAmount:(0,s.numeric)("advanceAmount",{precision:10,scale:2}).notNull(),remainingAmount:(0,s.numeric)("remainingAmount",{precision:10,scale:2}).notNull(),status:(0,n.varchar)("status",{length:30}).default("REQUESTED"),approvalExpiresAt:(0,a.timestamp)("approvalExpiresAt",{withTimezone:!0}).notNull(),notes:(0,n.varchar)("notes",{length:500}),source:(0,n.varchar)("source",{length:20}).default("WEB"),createdAt:(0,a.timestamp)("createdAt",{withTimezone:!0}).defaultNow(),updatedAt:(0,a.timestamp)("updatedAt",{withTimezone:!0}).defaultNow()});e.s(["vendorBookingsTable",0,c])},69334,e=>{"use strict";function t(e){return`
<!DOCTYPE html>
<html>
<body style="margin:0;font-family:Arial,sans-serif;background:#f4f4f4;">
  <table width="720" align="center"
    style="background:#fff;margin:20px auto;border-radius:12px;border:1px solid #e5e5e5;">
    
    <!-- HEADER -->
    <tr>
      <td style="padding:24px;text-align:center;background:#f8f8f8;">
        <img src="/logo.webp" width="80" />
        <h1 style="margin:10px 0;">SR Portraits & Events</h1>
        <p style="font-size:14px;color:#666;">INVOICE</p>
      </td>
    </tr>

    <!-- META -->
    <tr>
      <td style="padding:24px;">
        <table width="100%">
          <tr>
            <td>
              <strong>Invoice #</strong><br/>
              ${e.invoiceNumber}
            </td>
            <td align="right">
              <strong>Date</strong><br/>
              ${e.bookingDate}
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- PARTIES -->
    <tr>
      <td style="padding:24px;">
        <table width="100%">
          <tr>
            <td width="50%">
              <h3>Booked By</h3>
              <p>
                ${e.requester.name}<br/>
                ${e.requester.email}<br/>
                ${e.requester.phone}<br/>
                ${e.requester.address}
              </p>
            </td>

            <td width="50%">
              <h3>Service Provider</h3>
              <p>
                ${e.provider.name}<br/>
                ${e.provider.email}<br/>
                ${e.provider.phone}<br/>
                ${e.provider.address}
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- BOOKING DETAILS -->
    <tr>
      <td style="padding:24px;">
        <h3>Booking Details</h3>
        <table width="100%" border="1" cellspacing="0"
          style="border-collapse:collapse;font-size:14px;">
          
          <tr style="background:#f5f5f5;">
            <th align="left" style="padding:10px;">Service</th>
            <th align="left" style="padding:10px;">Dates</th>
            <th align="right" style="padding:10px;">Amount</th>
          </tr>
          <tr>
            <td colspan="2" align="right" style="padding:10px;">
              Discount
            </td>
            <td align="right" style="padding:10px;">
              -₹${e.discountAmount.toLocaleString()}
            </td>
          </tr>

          <tr>
            <td colspan="2" align="right" style="padding:10px;">
              Total Amount
            </td>
            <td align="right" style="padding:10px;">
              ₹${e.finalAmount.toLocaleString()}
            </td>
          </tr>

          <tr style="color:green;font-weight:bold;">
            <td colspan="2" align="right" style="padding:10px;">
              Advance Paid
            </td>
            <td align="right" style="padding:10px;">
              ₹${e.advanceAmount.toLocaleString()}
            </td>
          </tr>

          <tr style="color:#b91c1c;font-weight:bold;">
            <td colspan="2" align="right" style="padding:10px;">
              Remaining (Pay After Event)
            </td>
            <td align="right" style="padding:10px;">
              ₹${e.remainingAmount.toLocaleString()}
            </td>
          </tr>

        </table>
      </td>
    </tr>

    <!-- FOOTER -->
    <tr>
      <td style="padding:20px;text-align:center;background:#f2f2f2;font-size:12px;color:#777;">
        Thank you for choosing SR Portraits & Events
      </td>
    </tr>
  </table>
</body>
</html>`}e.s(["vendorInvoiceTemplate",()=>t])},27145,e=>e.a(async(t,r)=>{try{let t=await e.y("puppeteer");e.n(t),r()}catch(e){r(e)}},!0),1022,e=>e.a(async(t,r)=>{try{var n=e.i(27145),a=t([n]);async function o(e){let t=await n.default.launch({headless:!0}),r=await t.newPage();await r.setContent(e,{waitUntil:"networkidle0"});let a=await r.pdf({format:"A4",printBackground:!0,margin:{top:"20mm",bottom:"20mm",left:"15mm",right:"15mm"}});return await t.close(),Buffer.from(a)}[n]=a.then?(await a)():a,e.s(["generateInvoicePdf",()=>o]),r()}catch(e){r(e)}},!1),80137,e=>e.a(async(t,r)=>{try{var n=e.i(83111),a=e.i(67389),o=e.i(85881),i=e.i(50170),s=e.i(93632),d=e.i(97736),l=e.i(69516),u=e.i(69334),p=e.i(1022),c=t([p]);async function g(e,t){try{let{uuid:r}=await t.params,c=e.cookies.get("vendor_token")?.value;if(!c)return n.NextResponse.json({error:"Unauthorized"},{status:401});let g=a.default.verify(c,process.env.JWT_SECRET),[h]=await o.db.select().from(s.vendorBookingsTable).where((0,i.eq)(s.vendorBookingsTable.uuid,r));if(!h)return n.NextResponse.json({error:"Booking not found"},{status:404});if(h.vendorId!==g.vendorId&&h.bookedByVendorId!==g.vendorId)return n.NextResponse.json({error:"Forbidden"},{status:403});if(!h.status)return n.NextResponse.json({error:"Booking status not available"},{status:400});if("CONFIRMED"!==h.status&&"COMPLETED"!==h.status)return n.NextResponse.json({error:"Invoice not available yet"},{status:400});let[[m],[v]]=await Promise.all([o.db.select({businessName:d.vendorsTable.businessName,email:d.vendorsTable.email,phone:d.vendorsTable.phone,address:d.vendorsTable.address,profilePhoto:d.vendorsTable.profilePhoto}).from(d.vendorsTable).where((0,i.eq)(d.vendorsTable.id,h.bookedByVendorId)),o.db.select({businessName:d.vendorsTable.businessName,email:d.vendorsTable.email,phone:d.vendorsTable.phone,address:d.vendorsTable.address,profilePhoto:d.vendorsTable.profilePhoto}).from(d.vendorsTable).where((0,i.eq)(d.vendorsTable.id,h.vendorId))]),[f]=await o.db.select({title:l.vendorProductsTable.title}).from(l.vendorProductsTable).where((0,i.eq)(l.vendorProductsTable.id,h.vendorProductId)),b=Number(h.finalAmount),x=Number(h.advanceAmount??0),y="COMPLETED"===h.status?0:Math.max(b-x,0),w=(0,u.vendorInvoiceTemplate)({invoiceNumber:h.uuid,bookingDate:new Date().toLocaleDateString(),productTitle:f.title,bookingType:h.bookingType,startDate:h.startDate,endDate:h.endDate,totalDays:h.totalDays,basePrice:Number(h.totalAmount),discountAmount:Number(h.discountAmount),finalAmount:b,advanceAmount:x,remainingAmount:y,requester:{name:m.businessName,email:m.email,phone:m.phone,address:m.address,profilePhoto:m.profilePhoto},provider:{name:v.businessName,email:v.email,phone:v.phone,address:v.address,profilePhoto:v.profilePhoto}}),T=await (0,p.generateInvoicePdf)(w),R=new Uint8Array(T);return new n.NextResponse(R,{headers:{"Content-Type":"application/pdf","Content-Disposition":`attachment; filename=Invoice-${h.uuid}.pdf`}})}catch(e){return console.error("Invoice generation error:",e),n.NextResponse.json({error:"Failed to generate invoice"},{status:500})}}[p]=c.then?(await c)():c,e.s(["GET",()=>g]),r()}catch(e){r(e)}},!1),46192,e=>e.a(async(t,r)=>{try{var n=e.i(3745),a=e.i(59145),o=e.i(19643),i=e.i(5896),s=e.i(53795),d=e.i(42009),l=e.i(1654),u=e.i(1630),p=e.i(89727),c=e.i(71366),g=e.i(19441),h=e.i(44235),m=e.i(57281),v=e.i(477),f=e.i(52186),b=e.i(73929),x=e.i(93695);e.i(28633);var y=e.i(18897),w=e.i(80137),T=t([w]);[w]=T.then?(await T)():T;let E=new n.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/vendors/bookings/[uuid]/invoice/route",pathname:"/api/vendors/bookings/[uuid]/invoice",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/vendors/bookings/[uuid]/invoice/route.ts",nextConfigOutput:"",userland:w}),{workAsyncStorage:N,workUnitAsyncStorage:P,serverHooks:k}=E;function R(){return(0,o.patchFetch)({workAsyncStorage:N,workUnitAsyncStorage:P})}async function A(e,t,r){E.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/vendors/bookings/[uuid]/invoice/route";n=n.replace(/\/index$/,"")||"/";let o=await E.prepare(e,t,{srcPage:n,multiZoneDraftMode:!1});if(!o)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:w,params:T,nextConfig:R,parsedUrl:A,isDraftMode:N,prerenderManifest:P,routerServerContext:k,isOnDemandRevalidate:C,revalidateOnlyGenerated:D,resolvedPathname:I,clientReferenceManifest:q,serverActionsManifest:S}=o,O=(0,u.normalizeAppPath)(n),j=!!(P.dynamicRoutes[O]||P.routes[I]),$=async()=>((null==k?void 0:k.render404)?await k.render404(e,t,A,!1):t.end("This page could not be found"),null);if(j&&!N){let e=!!P.routes[I],t=P.dynamicRoutes[O];if(t&&!1===t.fallback&&!e){if(R.experimental.adapterPath)return await $();throw new x.NoFallbackError}}let _=null;!j||E.isDev||N||(_=I,_="/index"===_?"/":_);let M=!0===E.isDev||!j,B=j&&!M;S&&q&&(0,d.setReferenceManifestsSingleton)({page:n,clientReferenceManifest:q,serverActionsManifest:S,serverModuleMap:(0,l.createServerModuleMap)({serverActionsManifest:S})});let U=e.method||"GET",H=(0,s.getTracer)(),L=H.getActiveScopeSpan(),F={params:T,prerenderManifest:P,renderOpts:{experimental:{authInterrupts:!!R.experimental.authInterrupts},cacheComponents:!!R.cacheComponents,supportsDynamicResponse:M,incrementalCache:(0,i.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:R.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,n)=>E.onRequestError(e,t,n,k)},sharedContext:{buildId:w}},K=new p.NodeNextRequest(e),z=new p.NodeNextResponse(t),V=c.NextRequestAdapter.fromNodeNextRequest(K,(0,c.signalFromNodeResponse)(t));try{let o=async e=>E.handle(V,F).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=H.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==g.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${U} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${U} ${n}`)}),d=!!(0,i.getRequestMeta)(e,"minimalMode"),l=async i=>{var s,l;let u=async({previousCacheEntry:a})=>{try{if(!d&&C&&D&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let n=await o(i);e.fetchMetrics=F.renderOpts.fetchMetrics;let s=F.renderOpts.pendingWaitUntil;s&&r.waitUntil&&(r.waitUntil(s),s=void 0);let l=F.renderOpts.collectedTags;if(!j)return await (0,m.sendResponse)(K,z,n,F.renderOpts.pendingWaitUntil),null;{let e=await n.blob(),t=(0,v.toNodeOutgoingHttpHeaders)(n.headers);l&&(t[b.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==F.renderOpts.collectedRevalidate&&!(F.renderOpts.collectedRevalidate>=b.INFINITE_CACHE)&&F.renderOpts.collectedRevalidate,a=void 0===F.renderOpts.collectedExpire||F.renderOpts.collectedExpire>=b.INFINITE_CACHE?void 0:F.renderOpts.collectedExpire;return{value:{kind:y.CachedRouteKind.APP_ROUTE,status:n.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==a?void 0:a.isStale)&&await E.onRequestError(e,t,{routerKind:"App Router",routePath:n,routeType:"route",revalidateReason:(0,h.getRevalidateReason)({isStaticGeneration:B,isOnDemandRevalidate:C})},k),t}},p=await E.handleResponse({req:e,nextConfig:R,cacheKey:_,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:P,isRoutePPREnabled:!1,isOnDemandRevalidate:C,revalidateOnlyGenerated:D,responseGenerator:u,waitUntil:r.waitUntil,isMinimalMode:d});if(!j)return null;if((null==p||null==(s=p.value)?void 0:s.kind)!==y.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});d||t.setHeader("x-nextjs-cache",C?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),N&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,v.fromNodeOutgoingHttpHeaders)(p.value.headers);return d&&j||c.delete(b.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,f.getCacheControlHeader)(p.cacheControl)),await (0,m.sendResponse)(K,z,new Response(p.value.body,{headers:c,status:p.value.status||200})),null};L?await l(L):await H.withPropagatedContext(e.headers,()=>H.trace(g.BaseServerSpan.handleRequest,{spanName:`${U} ${n}`,kind:s.SpanKind.SERVER,attributes:{"http.method":U,"http.target":e.url}},l))}catch(t){if(t instanceof x.NoFallbackError||await E.onRequestError(e,t,{routerKind:"App Router",routePath:O,routeType:"route",revalidateReason:(0,h.getRevalidateReason)({isStaticGeneration:B,isOnDemandRevalidate:C})}),j)throw t;return await (0,m.sendResponse)(K,z,new Response(null,{status:500})),null}}e.s(["handler",()=>A,"patchFetch",()=>R,"routeModule",()=>E,"serverHooks",()=>k,"workAsyncStorage",()=>N,"workUnitAsyncStorage",()=>P]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__c640863f._.js.map