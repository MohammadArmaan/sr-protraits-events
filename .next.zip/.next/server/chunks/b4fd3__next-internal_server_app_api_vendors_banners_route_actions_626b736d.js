module.exports=[19371,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_banners_route_actions_626b736d.js.map