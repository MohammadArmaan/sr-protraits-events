module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},24361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},88947,(e,t,r)=>{t.exports=e.x("stream",()=>require("stream"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},27699,(e,t,r)=>{t.exports=e.x("events",()=>require("events"))},92509,(e,t,r)=>{t.exports=e.x("url",()=>require("url"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},21517,(e,t,r)=>{t.exports=e.x("http",()=>require("http"))},24836,(e,t,r)=>{t.exports=e.x("https",()=>require("https"))},6461,(e,t,r)=>{t.exports=e.x("zlib",()=>require("zlib"))},46786,(e,t,r)=>{t.exports=e.x("os",()=>require("os"))},54535,e=>{"use strict";var t=e.i(60914);async function r({to:e,subject:r,html:s,attachments:n}){try{let o=t.default.createTransport({service:"gmail",auth:{user:process.env.GMAIL_EMAIL,pass:process.env.GMAIL_APP_PASSWORD}});return await o.sendMail({from:`SR Portraits & Events <${process.env.GMAIL_EMAIL}>`,to:e,subject:r,html:s,attachments:n}),{success:!0}}catch(e){return console.error("Email Send Error:",e),{success:!1,error:e}}}e.s(["sendEmail",()=>r])},59485,(e,t,r)=>{t.exports=e.x("@aws-sdk/client-s3",()=>require("@aws-sdk/client-s3"))},66457,e=>{"use strict";var t=e.i(3745),r=e.i(59145),s=e.i(19643),n=e.i(5896),o=e.i(53795),a=e.i(42009),i=e.i(1654),l=e.i(1630),d=e.i(89727),p=e.i(71366),u=e.i(19441),c=e.i(44235),x=e.i(57281),h=e.i(477),f=e.i(52186),m=e.i(73929),v=e.i(93695);e.i(28633);var g=e.i(18897),R=e.i(83111),E=e.i(85881),w=e.i(51559),y=e.i(97736),b=e.i(50170),A=e.i(67389),C=e.i(59485),P=e.i(54535);let S=new C.S3Client({region:process.env.AWS_REGION,credentials:{accessKeyId:process.env.AWS_ACCESS_KEY,secretAccessKey:process.env.AWS_SECRET_ACCESS}});async function j(e){try{var t;let r,s=e.cookies.get("admin_token")?.value;if(!s)return R.NextResponse.json({error:"Unauthorized"},{status:401});try{r=A.default.verify(s,process.env.JWT_SECRET)}catch{return R.NextResponse.json({error:"Invalid token"},{status:401})}if("admin"!==r.role)return R.NextResponse.json({error:"Permission denied"},{status:403});let n=await e.json(),o=Number(n.editId);if(!o)return R.NextResponse.json({error:"Missing editId"},{status:400});let[a]=await E.db.select().from(w.vendorProfileEdits).where((0,b.eq)(w.vendorProfileEdits.id,o));if(!a)return R.NextResponse.json({error:"Request not found"},{status:404});if("PENDING"!==a.status)return R.NextResponse.json({error:"Already processed"},{status:400});let[i]=await E.db.select().from(y.vendorsTable).where((0,b.eq)(y.vendorsTable.id,a.vendorId));if(!i)return R.NextResponse.json({error:"Vendor not found"},{status:404});if(a.newProfilePhotoUrl){let e=a.newProfilePhotoUrl.split(".com/")[1];e&&await S.send(new C.DeleteObjectCommand({Bucket:process.env.AWS_S3_BUCKET_NAME,Key:e}))}for(let e of Array.isArray(a.newBusinessPhotos)?a.newBusinessPhotos:[]){let t=e.split(".com/")[1];t&&await S.send(new C.DeleteObjectCommand({Bucket:process.env.AWS_S3_BUCKET_NAME,Key:t}))}return await E.db.update(w.vendorProfileEdits).set({status:"REJECTED",rejectedByAdminId:r.adminId,reviewedAt:new Date}).where((0,b.eq)(w.vendorProfileEdits.id,o)),await (0,P.sendEmail)({to:i.email,subject:"Your Profile Edit Request Was Rejected",html:(t=i.fullName,`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;padding:0;margin:0;font-family:Arial,sans-serif;">

    <table width="600" align="center" cellpadding="0" cellspacing="0"
           style="background:white;margin:20px auto;border-radius:12px;
                  border:1px solid #e5e5e5;overflow:hidden;">

      <!-- HEADER -->
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" style="margin-bottom:10px;" />
          <h1 style="margin:0;font-size:26px;color:hsl(222,47%,11%);">
            SR Portraits & Events
          </h1>
        </td>
      </tr>

      <!-- BODY -->
      <tr>
        <td style="padding:35px 40px;text-align:center;">

          <h2 style="margin-bottom:10px;font-size:24px;color:hsl(222,47%,11%);">
            Hi, ${t}
          </h2>

          <p style="font-size:16px;color:#444;margin-bottom:25px;">
            Unfortunately, your recent vendor profile update request has been 
            <strong>rejected</strong> by our admin team.
          </p>

          <p style="font-size:15px;color:#666;margin-bottom:25px;">
            This may be because the provided information did not meet our platform 
            guidelines or needs correction.
          </p>

          <a href="${process.env.DOMAIN}/vendor/profile"
             style="
                display:inline-block;
                padding:16px 36px;
                font-size:16px;
                font-weight:bold;
                color:white;
                text-decoration:none;
                border-radius:9999px;
                background:linear-gradient(135deg, hsl(0, 80%, 55%), hsl(10, 70%, 50%));
                box-shadow:0 8px 32px -8px rgba(0,0,0,0.25);
                margin-top:20px;
             ">
            Review & Resubmit Changes
          </a>

          <p style="margin-top:28px;color:#666;font-size:14px;">
            If you think this was a mistake, feel free to reach out to support.
          </p>

        </td>
      </tr>

      <!-- FOOTER -->
      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;color:#777;font-size:12px;">
          &copy; ${new Date().getFullYear()} SR Portraits & Events. All rights reserved.
        </td>
      </tr>

    </table>

  </body>
</html>`)}),R.NextResponse.json({success:!0,message:"Profile edit rejected"},{status:200})}catch(e){return console.error("Reject Error:",e),R.NextResponse.json({error:"Server error rejecting request"},{status:500})}}e.s(["POST",()=>j],82240);var N=e.i(82240);let q=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/admin/profile-edits/reject/route",pathname:"/api/admin/profile-edits/reject",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/admin/profile-edits/reject/route.ts",nextConfigOutput:"",userland:N}),{workAsyncStorage:T,workUnitAsyncStorage:_,serverHooks:k}=q;function I(){return(0,s.patchFetch)({workAsyncStorage:T,workUnitAsyncStorage:_})}async function O(e,t,s){q.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let R="/api/admin/profile-edits/reject/route";R=R.replace(/\/index$/,"")||"/";let E=await q.prepare(e,t,{srcPage:R,multiZoneDraftMode:!1});if(!E)return t.statusCode=400,t.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve()),null;let{buildId:w,params:y,nextConfig:b,parsedUrl:A,isDraftMode:C,prerenderManifest:P,routerServerContext:S,isOnDemandRevalidate:j,revalidateOnlyGenerated:N,resolvedPathname:T,clientReferenceManifest:_,serverActionsManifest:k}=E,I=(0,l.normalizeAppPath)(R),O=!!(P.dynamicRoutes[I]||P.routes[T]),M=async()=>((null==S?void 0:S.render404)?await S.render404(e,t,A,!1):t.end("This page could not be found"),null);if(O&&!C){let e=!!P.routes[T],t=P.dynamicRoutes[I];if(t&&!1===t.fallback&&!e){if(b.experimental.adapterPath)return await M();throw new v.NoFallbackError}}let D=null;!O||q.isDev||C||(D="/index"===(D=T)?"/":D);let U=!0===q.isDev||!O,H=O&&!U;k&&_&&(0,a.setReferenceManifestsSingleton)({page:R,clientReferenceManifest:_,serverActionsManifest:k,serverModuleMap:(0,i.createServerModuleMap)({serverActionsManifest:k})});let K=e.method||"GET",B=(0,o.getTracer)(),$=B.getActiveScopeSpan(),z={params:y,prerenderManifest:P,renderOpts:{experimental:{authInterrupts:!!b.experimental.authInterrupts},cacheComponents:!!b.cacheComponents,supportsDynamicResponse:U,incrementalCache:(0,n.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:b.cacheLife,waitUntil:s.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,s)=>q.onRequestError(e,t,s,S)},sharedContext:{buildId:w}},F=new d.NodeNextRequest(e),L=new d.NodeNextResponse(t),W=p.NextRequestAdapter.fromNodeNextRequest(F,(0,p.signalFromNodeResponse)(t));try{let a=async e=>q.handle(W,z).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=B.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let s=r.get("next.route");if(s){let t=`${K} ${s}`;e.setAttributes({"next.route":s,"http.route":s,"next.span_name":t}),e.updateName(t)}else e.updateName(`${K} ${R}`)}),i=!!(0,n.getRequestMeta)(e,"minimalMode"),l=async n=>{var o,l;let d=async({previousCacheEntry:r})=>{try{if(!i&&j&&N&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await a(n);e.fetchMetrics=z.renderOpts.fetchMetrics;let l=z.renderOpts.pendingWaitUntil;l&&s.waitUntil&&(s.waitUntil(l),l=void 0);let d=z.renderOpts.collectedTags;if(!O)return await (0,x.sendResponse)(F,L,o,z.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(o.headers);d&&(t[m.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==z.renderOpts.collectedRevalidate&&!(z.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&z.renderOpts.collectedRevalidate,s=void 0===z.renderOpts.collectedExpire||z.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:z.renderOpts.collectedExpire;return{value:{kind:g.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:s}}}}catch(t){throw(null==r?void 0:r.isStale)&&await q.onRequestError(e,t,{routerKind:"App Router",routePath:R,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:j})},S),t}},p=await q.handleResponse({req:e,nextConfig:b,cacheKey:D,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:P,isRoutePPREnabled:!1,isOnDemandRevalidate:j,revalidateOnlyGenerated:N,responseGenerator:d,waitUntil:s.waitUntil,isMinimalMode:i});if(!O)return null;if((null==p||null==(o=p.value)?void 0:o.kind)!==g.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",j?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),C&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let u=(0,h.fromNodeOutgoingHttpHeaders)(p.value.headers);return i&&O||u.delete(m.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||u.get("Cache-Control")||u.set("Cache-Control",(0,f.getCacheControlHeader)(p.cacheControl)),await (0,x.sendResponse)(F,L,new Response(p.value.body,{headers:u,status:p.value.status||200})),null};$?await l($):await B.withPropagatedContext(e.headers,()=>B.trace(u.BaseServerSpan.handleRequest,{spanName:`${K} ${R}`,kind:o.SpanKind.SERVER,attributes:{"http.method":K,"http.target":e.url}},l))}catch(t){if(t instanceof v.NoFallbackError||await q.onRequestError(e,t,{routerKind:"App Router",routePath:I,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:j})}),O)throw t;return await (0,x.sendResponse)(F,L,new Response(null,{status:500})),null}}e.s(["handler",()=>O,"patchFetch",()=>I,"routeModule",()=>q,"serverHooks",()=>k,"workAsyncStorage",()=>T,"workUnitAsyncStorage",()=>_],66457)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__7b4d2678._.js.map