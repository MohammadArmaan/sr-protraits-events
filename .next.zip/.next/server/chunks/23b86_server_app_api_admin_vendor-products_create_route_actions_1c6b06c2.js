module.exports=[56170,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_admin_vendor-products_create_route_actions_1c6b06c2.js.map