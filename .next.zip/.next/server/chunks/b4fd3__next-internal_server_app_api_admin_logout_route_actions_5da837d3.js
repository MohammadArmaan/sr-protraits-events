module.exports=[89981,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_admin_logout_route_actions_5da837d3.js.map