module.exports=[91212,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_bookings_%5Buuid%5D_route_actions_30a9118a.js.map