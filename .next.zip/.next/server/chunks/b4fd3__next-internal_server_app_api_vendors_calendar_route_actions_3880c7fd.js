module.exports=[3108,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_calendar_route_actions_3880c7fd.js.map