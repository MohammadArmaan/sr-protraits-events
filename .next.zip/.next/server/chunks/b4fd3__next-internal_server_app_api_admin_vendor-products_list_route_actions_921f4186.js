module.exports=[34388,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_admin_vendor-products_list_route_actions_921f4186.js.map