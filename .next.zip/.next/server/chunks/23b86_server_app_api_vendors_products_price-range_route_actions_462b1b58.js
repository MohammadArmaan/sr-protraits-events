module.exports=[63024,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_vendors_products_price-range_route_actions_462b1b58.js.map