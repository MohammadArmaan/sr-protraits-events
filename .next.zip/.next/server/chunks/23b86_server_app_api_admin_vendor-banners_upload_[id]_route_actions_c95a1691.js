module.exports=[51420,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_admin_vendor-banners_upload_%5Bid%5D_route_actions_c95a1691.js.map