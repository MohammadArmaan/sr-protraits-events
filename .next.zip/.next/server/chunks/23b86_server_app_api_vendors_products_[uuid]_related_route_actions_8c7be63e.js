module.exports=[20979,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_vendors_products_%5Buuid%5D_related_route_actions_8c7be63e.js.map