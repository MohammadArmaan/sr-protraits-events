module.exports=[11897,e=>{"use strict";function t(e,t){return`
<!DOCTYPE html>
<html>
<body style="background:#f4f4f4;margin:0;font-family:Arial,sans-serif;">
<table width="600" align="center"
       style="background:white;margin:20px auto;
              border-radius:12px;border:1px solid #e5e5e5;">

<tr>
<td style="padding:30px;text-align:center;">

<img src="/logo.webp" width="90" style="margin-bottom:10px;" />

<h2 style="margin:0 0 10px;color:#111;">
Payment Completed 🎉
</h2>

<p style="font-size:16px;color:#444;">
Hi <strong>${e}</strong>,
</p>

<p style="font-size:15px;color:#555;margin:20px 0;">
The remaining payment for your completed event
(<strong>Booking ID: ${t}</strong>) has been successfully received.
</p>

<p style="font-size:15px;color:#555;">
Your payout is now being processed and will be credited to your
registered bank account within <strong>24–48 hours</strong>.
</p>

<a href="${process.env.DOMAIN}/vendor/orders"
   style="
      display:inline-block;
      padding:14px 36px;
      background:linear-gradient(135deg, hsl(220, 80%, 55%), hsl(180, 70%, 50%));
      color:white;
      text-decoration:none;
      border-radius:9999px;
      font-weight:bold;
      margin-top:25px;
   ">
View Order & Invoice
</a>

<p style="margin-top:30px;font-size:13px;color:#777;">
You can download your invoice anytime from your dashboard.
</p>

</td>
</tr>

<tr>
<td style="padding:16px;text-align:center;
           background:#f2f2f2;color:#777;font-size:12px;">
&copy; ${new Date().getFullYear()} SR Portraits & Events. All rights reserved.
</td>
</tr>

</table>
</body>
</html>
`}e.s(["remainingPaymentCompletedTemplate",()=>t])},11954,e=>{"use strict";function t({requesterName:e,bookingRef:t,productUuid:n}){return`
<!DOCTYPE html>
<html>
<body style="background:#f4f4f4;margin:0;font-family:Arial,sans-serif;">
<table width="600" align="center"
       style="background:white;margin:20px auto;
              border-radius:12px;border:1px solid #e5e5e5;">

<tr>
<td style="padding:30px;text-align:center;">

<img src="/logo.webp" width="90" style="margin-bottom:10px;" />

<h2 style="margin:0 0 10px;color:#111;">
Booking Completed 🎉
</h2>

<p style="font-size:16px;color:#444;">
Hi <strong>${e}</strong>,
</p>

<p style="font-size:15px;color:#555;margin:20px 0;">
Your booking (<strong>ID: ${t}</strong>) has been successfully completed,
and the final payment has been received.
</p>

<p style="font-size:15px;color:#555;margin-bottom:24px;">
We hope you had a great experience!  
Your feedback helps vendors improve and helps others book with confidence.
</p>

<!-- CTA Buttons -->
<div style="margin:30px 0;">
    <a href="${process.env.DOMAIN}/calendar"
       style="
          display:inline-block;
          padding:14px 28px;
          background:linear-gradient(135deg, hsl(220, 80%, 55%), hsl(180, 70%, 50%));
          color:white;
          text-decoration:none;
          border-radius:9999px;
          font-weight:bold;
          margin:0 8px 12px;
       ">
       View Calendar
    </a>

    <a href="${process.env.DOMAIN}/vendor/product/${n}"
       style="
          display:inline-block;
          padding:14px 28px;
          background:linear-gradient(135deg, hsl(260, 70%, 60%), hsl(220, 80%, 55%));
          color:white;
          text-decoration:none;
          border-radius:9999px;
          font-weight:bold;
          margin:0 8px 12px;
       ">
       Review Vendor
    </a>
</div>

<p style="font-size:14px;color:#666;margin-top:20px;">
You can view your booking history, invoices, and upcoming events
anytime from your calendar.
</p>

</td>
</tr>

<tr>
<td style="padding:16px;text-align:center;
           background:#f2f2f2;color:#777;font-size:12px;">
&copy; ${new Date().getFullYear()} SR Portraits & Events. All rights reserved.
</td>
</tr>

</table>
</body>
</html>
`}e.s(["requesterPaymentCompletedTemplate",()=>t])},37762,e=>e.a(async(t,n)=>{try{var r=e.i(83111),o=e.i(54799),a=e.i(85881),i=e.i(50170),s=e.i(11187),d=e.i(93632),l=e.i(97736),u=e.i(54535),p=e.i(1022),c=e.i(69334),m=e.i(11897),g=e.i(11954),h=e.i(69516),f=t([p]);async function y(e){try{let{razorpay_order_id:t,razorpay_payment_id:n,razorpay_signature:f}=await e.json(),y=`${t}|${n}`;if(o.default.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET).update(y).digest("hex")!==f)return r.NextResponse.json({error:"Invalid payment signature"},{status:400});let[b]=await a.db.update(s.vendorPaymentsTable).set({razorpayPaymentId:n,razorpaySignature:f,status:"COMPLETED",updatedAt:new Date}).where((0,i.eq)(s.vendorPaymentsTable.razorpayOrderId,t)).returning();if(!b)return r.NextResponse.json({error:"Remaining payment not found"},{status:404});let[v]=await a.db.select().from(d.vendorBookingsTable).where((0,i.eq)(d.vendorBookingsTable.vendorProductId,b.vendorProductId));if(!v)return r.NextResponse.json({error:"Booking not found"},{status:404});if(!v.paymentId)return r.NextResponse.json({error:"Advance payment missing"},{status:400});let[x]=await a.db.select().from(s.vendorPaymentsTable).where((0,i.eq)(s.vendorPaymentsTable.id,v.paymentId));if(!x||"PAID"!==x.status)return r.NextResponse.json({error:"Advance payment not completed"},{status:400});let w=x.amount/100,R=b.amount/100,P=w+R,T=Number(v.totalAmount)-Number(v.discountAmount);if(Number(P.toFixed(2))!==Number(T.toFixed(2)))return console.error("❌ Settlement mismatch",{bookingUuid:v.uuid,advanceAmount:w,remainingAmount:R,totalPaid:P,finalAmount:T}),r.NextResponse.json({error:"Payment mismatch. Settlement aborted."},{status:400});let[E]=await a.db.update(d.vendorBookingsTable).set({status:"COMPLETED",remainingAmount:"0",updatedAt:new Date}).where((0,i.eq)(d.vendorBookingsTable.id,v.id)).returning(),[[A],[C]]=await Promise.all([a.db.select().from(l.vendorsTable).where((0,i.eq)(l.vendorsTable.id,v.bookedByVendorId)),a.db.select().from(l.vendorsTable).where((0,i.eq)(l.vendorsTable.id,v.vendorId))]),k=(0,c.vendorInvoiceTemplate)({invoiceNumber:E.uuid,bookingDate:new Date().toLocaleDateString(),productTitle:E.uuid,bookingType:E.bookingType,startDate:E.startDate,endDate:E.endDate,totalDays:E.totalDays,basePrice:Number(E.totalAmount),discountAmount:Number(E.discountAmount),finalAmount:T,advanceAmount:w,remainingAmount:0,requester:{name:A.businessName,email:A.email,phone:A.phone,address:A.address,profilePhoto:A.profilePhoto},provider:{name:C.businessName,email:C.email,phone:C.phone,address:C.address,profilePhoto:C.profilePhoto}}),N=await (0,p.generateInvoicePdf)(k);await (0,u.sendEmail)({to:C.email,subject:"Booking Settled – Payment Completed ✅",html:(0,m.remainingPaymentCompletedTemplate)(C.businessName,E.uuid),attachments:[{filename:`Invoice-${E.uuid}.pdf`,content:N,contentType:"application/pdf"}]});let[D]=await a.db.select({uuid:h.vendorProductsTable.uuid}).from(h.vendorProductsTable).where((0,i.eq)(h.vendorProductsTable.id,v.vendorProductId));if(!D)return r.NextResponse.json({error:"Product not found"},{status:404});return await (0,u.sendEmail)({to:A.email,subject:"Your Booking Is Completed – Share Your Experience 🌟",html:(0,g.requesterPaymentCompletedTemplate)({requesterName:A.businessName,bookingRef:E.uuid,productUuid:D.uuid}),attachments:[{filename:`Invoice-${E.uuid}.pdf`,content:N,contentType:"application/pdf"}]}),r.NextResponse.json({success:!0})}catch(e){return console.error("Verify remaining payment error:",e),r.NextResponse.json({error:"Remaining payment verification failed"},{status:500})}}[p]=f.then?(await f)():f,e.s(["POST",()=>y]),n()}catch(e){n(e)}},!1),94865,e=>e.a(async(t,n)=>{try{var r=e.i(3745),o=e.i(59145),a=e.i(19643),i=e.i(5896),s=e.i(53795),d=e.i(42009),l=e.i(1654),u=e.i(1630),p=e.i(89727),c=e.i(71366),m=e.i(19441),g=e.i(44235),h=e.i(57281),f=e.i(477),y=e.i(52186),b=e.i(73929),v=e.i(93695);e.i(28633);var x=e.i(18897),w=e.i(37762),R=t([w]);[w]=R.then?(await R)():R;let E=new r.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/vendors/bookings/payment/verify-remaining/route",pathname:"/api/vendors/bookings/payment/verify-remaining",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/vendors/bookings/payment/verify-remaining/route.ts",nextConfigOutput:"",userland:w}),{workAsyncStorage:A,workUnitAsyncStorage:C,serverHooks:k}=E;function P(){return(0,a.patchFetch)({workAsyncStorage:A,workUnitAsyncStorage:C})}async function T(e,t,n){E.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/vendors/bookings/payment/verify-remaining/route";r=r.replace(/\/index$/,"")||"/";let a=await E.prepare(e,t,{srcPage:r,multiZoneDraftMode:!1});if(!a)return t.statusCode=400,t.end("Bad Request"),null==n.waitUntil||n.waitUntil.call(n,Promise.resolve()),null;let{buildId:w,params:R,nextConfig:P,parsedUrl:T,isDraftMode:A,prerenderManifest:C,routerServerContext:k,isOnDemandRevalidate:N,revalidateOnlyGenerated:D,resolvedPathname:I,clientReferenceManifest:O,serverActionsManifest:S}=a,q=(0,u.normalizeAppPath)(r),$=!!(C.dynamicRoutes[q]||C.routes[I]),_=async()=>((null==k?void 0:k.render404)?await k.render404(e,t,T,!1):t.end("This page could not be found"),null);if($&&!A){let e=!!C.routes[I],t=C.dynamicRoutes[q];if(t&&!1===t.fallback&&!e){if(P.experimental.adapterPath)return await _();throw new v.NoFallbackError}}let M=null;!$||E.isDev||A||(M=I,M="/index"===M?"/":M);let j=!0===E.isDev||!$,H=$&&!j;S&&O&&(0,d.setReferenceManifestsSingleton)({page:r,clientReferenceManifest:O,serverActionsManifest:S,serverModuleMap:(0,l.createServerModuleMap)({serverActionsManifest:S})});let U=e.method||"GET",B=(0,s.getTracer)(),z=B.getActiveScopeSpan(),Y={params:R,prerenderManifest:C,renderOpts:{experimental:{authInterrupts:!!P.experimental.authInterrupts},cacheComponents:!!P.cacheComponents,supportsDynamicResponse:j,incrementalCache:(0,i.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:P.cacheLife,waitUntil:n.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,n,r)=>E.onRequestError(e,t,r,k)},sharedContext:{buildId:w}},F=new p.NodeNextRequest(e),K=new p.NodeNextResponse(t),L=c.NextRequestAdapter.fromNodeNextRequest(F,(0,c.signalFromNodeResponse)(t));try{let a=async e=>E.handle(L,Y).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let n=B.getRootSpanAttributes();if(!n)return;if(n.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${n.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let o=n.get("next.route");if(o){let t=`${U} ${o}`;e.setAttributes({"next.route":o,"http.route":o,"next.span_name":t}),e.updateName(t)}else e.updateName(`${U} ${r}`)}),d=!!(0,i.getRequestMeta)(e,"minimalMode"),l=async i=>{var s,l;let u=async({previousCacheEntry:o})=>{try{if(!d&&N&&D&&!o)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let r=await a(i);e.fetchMetrics=Y.renderOpts.fetchMetrics;let s=Y.renderOpts.pendingWaitUntil;s&&n.waitUntil&&(n.waitUntil(s),s=void 0);let l=Y.renderOpts.collectedTags;if(!$)return await (0,h.sendResponse)(F,K,r,Y.renderOpts.pendingWaitUntil),null;{let e=await r.blob(),t=(0,f.toNodeOutgoingHttpHeaders)(r.headers);l&&(t[b.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let n=void 0!==Y.renderOpts.collectedRevalidate&&!(Y.renderOpts.collectedRevalidate>=b.INFINITE_CACHE)&&Y.renderOpts.collectedRevalidate,o=void 0===Y.renderOpts.collectedExpire||Y.renderOpts.collectedExpire>=b.INFINITE_CACHE?void 0:Y.renderOpts.collectedExpire;return{value:{kind:x.CachedRouteKind.APP_ROUTE,status:r.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:n,expire:o}}}}catch(t){throw(null==o?void 0:o.isStale)&&await E.onRequestError(e,t,{routerKind:"App Router",routePath:r,routeType:"route",revalidateReason:(0,g.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:N})},k),t}},p=await E.handleResponse({req:e,nextConfig:P,cacheKey:M,routeKind:o.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:C,isRoutePPREnabled:!1,isOnDemandRevalidate:N,revalidateOnlyGenerated:D,responseGenerator:u,waitUntil:n.waitUntil,isMinimalMode:d});if(!$)return null;if((null==p||null==(s=p.value)?void 0:s.kind)!==x.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==p||null==(l=p.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});d||t.setHeader("x-nextjs-cache",N?"REVALIDATED":p.isMiss?"MISS":p.isStale?"STALE":"HIT"),A&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,f.fromNodeOutgoingHttpHeaders)(p.value.headers);return d&&$||c.delete(b.NEXT_CACHE_TAGS_HEADER),!p.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,y.getCacheControlHeader)(p.cacheControl)),await (0,h.sendResponse)(F,K,new Response(p.value.body,{headers:c,status:p.value.status||200})),null};z?await l(z):await B.withPropagatedContext(e.headers,()=>B.trace(m.BaseServerSpan.handleRequest,{spanName:`${U} ${r}`,kind:s.SpanKind.SERVER,attributes:{"http.method":U,"http.target":e.url}},l))}catch(t){if(t instanceof v.NoFallbackError||await E.onRequestError(e,t,{routerKind:"App Router",routePath:q,routeType:"route",revalidateReason:(0,g.getRevalidateReason)({isStaticGeneration:H,isOnDemandRevalidate:N})}),$)throw t;return await (0,h.sendResponse)(F,K,new Response(null,{status:500})),null}}e.s(["handler",()=>T,"patchFetch",()=>P,"routeModule",()=>E,"serverHooks",()=>k,"workAsyncStorage",()=>A,"workUnitAsyncStorage",()=>C]),n()}catch(e){n(e)}},!1)];

//# sourceMappingURL=Documents_Nextjs_sr-portriats-events_efdbea61._.js.map