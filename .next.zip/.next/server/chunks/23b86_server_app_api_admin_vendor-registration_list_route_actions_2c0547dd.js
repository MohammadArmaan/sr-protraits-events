module.exports=[60576,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_admin_vendor-registration_list_route_actions_2c0547dd.js.map