module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},24361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},54799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},88947,(e,t,r)=>{t.exports=e.x("stream",()=>require("stream"))},14747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},27699,(e,t,r)=>{t.exports=e.x("events",()=>require("events"))},92509,(e,t,r)=>{t.exports=e.x("url",()=>require("url"))},22734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},21517,(e,t,r)=>{t.exports=e.x("http",()=>require("http"))},24836,(e,t,r)=>{t.exports=e.x("https",()=>require("https"))},6461,(e,t,r)=>{t.exports=e.x("zlib",()=>require("zlib"))},46786,(e,t,r)=>{t.exports=e.x("os",()=>require("os"))},93632,e=>{"use strict";var t=e.i(71920),r=e.i(79559),n=e.i(28500),a=e.i(30503),i=e.i(44579),o=e.i(40408),s=e.i(18018),d=e.i(71145),l=e.i(97736),p=e.i(69516),u=e.i(11187);let c=(0,t.pgTable)("vendor_bookings",{id:(0,r.integer)().primaryKey().generatedAlwaysAsIdentity(),uuid:(0,d.uuid)("uuid").defaultRandom().notNull().unique(),vendorId:(0,r.integer)().notNull().references(()=>l.vendorsTable.id),bookedByVendorId:(0,r.integer)().notNull().references(()=>l.vendorsTable.id),vendorProductId:(0,r.integer)().notNull().references(()=>p.vendorProductsTable.id),paymentId:(0,r.integer)().references(()=>u.vendorPaymentsTable.id),bookingType:(0,n.varchar)("bookingType",{length:20}).notNull(),startDate:(0,i.date)("startDate").notNull(),endDate:(0,i.date)("endDate").notNull(),startTime:(0,o.time)("startTime"),endTime:(0,o.time)("endTime"),basePrice:(0,s.numeric)("basePrice",{precision:10,scale:2}).notNull(),totalDays:(0,r.integer)("totalDays").notNull(),totalAmount:(0,s.numeric)("totalAmount",{precision:10,scale:2}).notNull(),couponCode:(0,n.varchar)("couponCode",{length:50}),discountAmount:(0,s.numeric)("discountAmount",{precision:10,scale:2}).default("0"),finalAmount:(0,s.numeric)("finalAmount",{precision:10,scale:2}).notNull(),advanceAmount:(0,s.numeric)("advanceAmount",{precision:10,scale:2}).notNull(),remainingAmount:(0,s.numeric)("remainingAmount",{precision:10,scale:2}).notNull(),status:(0,n.varchar)("status",{length:30}).default("REQUESTED"),approvalExpiresAt:(0,a.timestamp)("approvalExpiresAt",{withTimezone:!0}).notNull(),notes:(0,n.varchar)("notes",{length:500}),source:(0,n.varchar)("source",{length:20}).default("WEB"),createdAt:(0,a.timestamp)("createdAt",{withTimezone:!0}).defaultNow(),updatedAt:(0,a.timestamp)("updatedAt",{withTimezone:!0}).defaultNow()});e.s(["vendorBookingsTable",0,c])},54535,e=>{"use strict";var t=e.i(60914);async function r({to:e,subject:r,html:n,attachments:a}){try{let i=t.default.createTransport({service:"gmail",auth:{user:process.env.GMAIL_EMAIL,pass:process.env.GMAIL_APP_PASSWORD}});return await i.sendMail({from:`SR Portraits & Events <${process.env.GMAIL_EMAIL}>`,to:e,subject:r,html:n,attachments:a}),{success:!0}}catch(e){return console.error("Email Send Error:",e),{success:!1,error:e}}}e.s(["sendEmail",()=>r])},69334,e=>{"use strict";function t(e){return`
<!DOCTYPE html>
<html>
<body style="margin:0;font-family:Arial,sans-serif;background:#f4f4f4;">
  <table width="720" align="center"
    style="background:#fff;margin:20px auto;border-radius:12px;border:1px solid #e5e5e5;">
    
    <!-- HEADER -->
    <tr>
      <td style="padding:24px;text-align:center;background:#f8f8f8;">
        <img src="/logo.webp" width="80" />
        <h1 style="margin:10px 0;">SR Portraits & Events</h1>
        <p style="font-size:14px;color:#666;">INVOICE</p>
      </td>
    </tr>

    <!-- META -->
    <tr>
      <td style="padding:24px;">
        <table width="100%">
          <tr>
            <td>
              <strong>Invoice #</strong><br/>
              ${e.invoiceNumber}
            </td>
            <td align="right">
              <strong>Date</strong><br/>
              ${e.bookingDate}
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- PARTIES -->
    <tr>
      <td style="padding:24px;">
        <table width="100%">
          <tr>
            <td width="50%">
              <h3>Booked By</h3>
              <p>
                ${e.requester.name}<br/>
                ${e.requester.email}<br/>
                ${e.requester.phone}<br/>
                ${e.requester.address}
              </p>
            </td>

            <td width="50%">
              <h3>Service Provider</h3>
              <p>
                ${e.provider.name}<br/>
                ${e.provider.email}<br/>
                ${e.provider.phone}<br/>
                ${e.provider.address}
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- BOOKING DETAILS -->
    <tr>
      <td style="padding:24px;">
        <h3>Booking Details</h3>
        <table width="100%" border="1" cellspacing="0"
          style="border-collapse:collapse;font-size:14px;">
          
          <tr style="background:#f5f5f5;">
            <th align="left" style="padding:10px;">Service</th>
            <th align="left" style="padding:10px;">Dates</th>
            <th align="right" style="padding:10px;">Amount</th>
          </tr>
          <tr>
            <td colspan="2" align="right" style="padding:10px;">
              Discount
            </td>
            <td align="right" style="padding:10px;">
              -₹${e.discountAmount.toLocaleString()}
            </td>
          </tr>

          <tr>
            <td colspan="2" align="right" style="padding:10px;">
              Total Amount
            </td>
            <td align="right" style="padding:10px;">
              ₹${e.finalAmount.toLocaleString()}
            </td>
          </tr>

          <tr style="color:green;font-weight:bold;">
            <td colspan="2" align="right" style="padding:10px;">
              Advance Paid
            </td>
            <td align="right" style="padding:10px;">
              ₹${e.advanceAmount.toLocaleString()}
            </td>
          </tr>

          <tr style="color:#b91c1c;font-weight:bold;">
            <td colspan="2" align="right" style="padding:10px;">
              Remaining (Pay After Event)
            </td>
            <td align="right" style="padding:10px;">
              ₹${e.remainingAmount.toLocaleString()}
            </td>
          </tr>

        </table>
      </td>
    </tr>

    <!-- FOOTER -->
    <tr>
      <td style="padding:20px;text-align:center;background:#f2f2f2;font-size:12px;color:#777;">
        Thank you for choosing SR Portraits & Events
      </td>
    </tr>
  </table>
</body>
</html>`}e.s(["vendorInvoiceTemplate",()=>t])},27145,e=>e.a(async(t,r)=>{try{let t=await e.y("puppeteer");e.n(t),r()}catch(e){r(e)}},!0),1022,e=>e.a(async(t,r)=>{try{var n=e.i(27145),a=t([n]);async function i(e){let t=await n.default.launch({headless:!0}),r=await t.newPage();await r.setContent(e,{waitUntil:"networkidle0"});let a=await r.pdf({format:"A4",printBackground:!0,margin:{top:"20mm",bottom:"20mm",left:"15mm",right:"15mm"}});return await t.close(),Buffer.from(a)}[n]=a.then?(await a)():a,e.s(["generateInvoicePdf",()=>i]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__24480c21._.js.map