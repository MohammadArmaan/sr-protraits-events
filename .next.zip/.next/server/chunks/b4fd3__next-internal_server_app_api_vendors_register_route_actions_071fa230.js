module.exports=[50289,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_register_route_actions_071fa230.js.map