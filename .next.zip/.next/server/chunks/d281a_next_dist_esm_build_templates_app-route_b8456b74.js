module.exports=[25459,e=>{"use strict";var t=e.i(3745),r=e.i(59145),n=e.i(19643),o=e.i(5896),a=e.i(53795),s=e.i(42009),i=e.i(1654),l=e.i(1630),d=e.i(89727),u=e.i(71366),c=e.i(19441),p=e.i(44235),g=e.i(57281),v=e.i(477),f=e.i(52186),h=e.i(73929),b=e.i(93695);e.i(28633);var m=e.i(18897),R=e.i(83111),x=e.i(67389),w=e.i(85881),y=e.i(93632),E=e.i(69516),T=e.i(97736),N=e.i(50170),P=e.i(54535),k=e.i(19566);async function A(e,t){try{var r,n,o,a,s,i,l,d;let{uuid:u}=await t.params,c=e.cookies.get("vendor_token")?.value;if(!c)return R.NextResponse.json({error:"Unauthorized"},{status:401});let p=x.default.verify(c,process.env.JWT_SECRET);if(!(await w.db.select({id:k.vendorBankDetailsTable.id}).from(k.vendorBankDetailsTable).where((0,N.eq)(k.vendorBankDetailsTable.vendorId,p.vendorId)).limit(1)).length)return R.NextResponse.json({error:"Complete payout details before approving bookings."},{status:400});let{decision:g}=await e.json();if(!["APPROVE","REJECT"].includes(g))return R.NextResponse.json({error:"Invalid decision"},{status:400});let[v]=await w.db.select().from(y.vendorBookingsTable).where((0,N.eq)(y.vendorBookingsTable.uuid,u));if(!v)return R.NextResponse.json({error:"Booking not found"},{status:404});if(v.vendorId!==p.vendorId)return R.NextResponse.json({error:"Forbidden"},{status:403});if(new Date>v.approvalExpiresAt)return await w.db.update(y.vendorBookingsTable).set({status:"EXPIRED"}).where((0,N.eq)(y.vendorBookingsTable.id,v.id)),R.NextResponse.json({error:"Booking request expired"},{status:410});if(0>=Number(v.advanceAmount))return R.NextResponse.json({error:"Invalid advance amount"},{status:400});let[f]=await w.db.select({businessName:T.vendorsTable.businessName,email:T.vendorsTable.email}).from(T.vendorsTable).where((0,N.eq)(T.vendorsTable.id,v.bookedByVendorId));if(!f)return R.NextResponse.json({error:"Requesting vendor not found"},{status:404});let[h]=await w.db.select({title:E.vendorProductsTable.title,advanceType:E.vendorProductsTable.advanceType,advanceValue:E.vendorProductsTable.advanceValue}).from(E.vendorProductsTable).where((0,N.eq)(E.vendorProductsTable.id,v.vendorProductId));if(!h)return R.NextResponse.json({error:"Product not found"},{status:404});if("APPROVE"===g){let e=Number(v.finalAmount);h.advanceType&&h.advanceValue&&("PERCENTAGE"===h.advanceType&&(e=Math.round(Number(v.finalAmount)*Number(h.advanceValue)/100)),"FIXED"===h.advanceType&&(e=Number(h.advanceValue)),e=Math.min(e,Number(v.finalAmount))),await (0,P.sendEmail)({to:f.email,subject:"Booking Approved – Pay Advance 💳",html:(r=f.businessName,n=h.title,o=v.uuid,a=e,s=Number(v.finalAmount),i=v.totalDays>1?v.totalDays:void 0,`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;font-family:Arial,sans-serif;">
    <table width="600" align="center"
      style="background:white;margin:20px auto;border-radius:12px;border:1px solid #e5e5e5;">
      
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" />
          <h1>SR Portraits & Events</h1>
        </td>
      </tr>

      <tr>
        <td style="padding:35px 40px;text-align:center;">
          <h2>Good news ${r}! 🎉</h2>

          <p style="font-size:16px;color:#444;">
            Your booking request for <strong>"${n}"</strong>
            has been <strong>approved</strong>.
          </p>

          ${i&&i>1?`<p style="font-size:15px;color:#555;">
                   Duration: <strong>${i} days</strong>
                 </p>`:""}

          <table width="100%" cellpadding="0" cellspacing="0"
            style="margin:20px 0;font-size:15px;color:#333;">
            <tr>
              <td align="left">Total Booking Amount</td>
              <td align="right"><strong>₹${s.toLocaleString()}</strong></td>
            </tr>
            <tr>
              <td align="left">Advance Payable Now</td>
              <td align="right" style="color:#16a34a;">
                <strong>₹${a.toLocaleString()}</strong>
              </td>
            </tr>
          </table>

          <a href="${process.env.DOMAIN}/vendor/bookings/pay/${o}"
            style="display:inline-block;padding:16px 36px;
                   color:white;text-decoration:none;
                   border-radius:9999px;
                   background:linear-gradient(135deg, hsl(220, 80%, 55%), hsl(180, 70%, 50%));
                   font-weight:bold;margin-top:20px;">
            Pay Advance Now
          </a>

          <p style="margin-top:18px;font-size:13px;color:#777;">
            Remaining amount will be collected after event completion.
          </p>
        </td>
      </tr>

      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;
                   font-size:12px;color:#777;">
          \xa9 ${new Date().getFullYear()} SR Portraits & Events
        </td>
      </tr>
    </table>
  </body>
</html>`)})}"REJECT"===g&&await (0,P.sendEmail)({to:f.email,subject:"Booking Request Rejected",html:(l=f.businessName,d=h.title,`
<!DOCTYPE html>
<html>
  <body style="background:#f4f4f4;font-family:Arial,sans-serif;">
    <table width="600" align="center"
      style="background:white;margin:20px auto;border-radius:12px;border:1px solid #e5e5e5;">
      
      <tr>
        <td style="padding:28px;text-align:center;background:#f8f8f8;">
          <img src="/logo.webp" width="90" />
          <h1>SR Portraits & Events</h1>
        </td>
      </tr>

      <tr>
        <td style="padding:35px 40px;text-align:center;">
          <h2>Hello ${l}</h2>

          <p style="font-size:16px;color:#444;">
            Unfortunately, your booking request for
            <strong>"${d}"</strong>
            was <strong>rejected</strong>.
          </p>

          <p style="font-size:14px;color:#666;">
            You can try booking another vendor or choose a different date.
          </p>
        </td>
      </tr>

      <tr>
        <td style="padding:20px;text-align:center;background:#f2f2f2;
                   font-size:12px;color:#777;">
          \xa9 ${new Date().getFullYear()} SR Portraits & Events
        </td>
      </tr>
    </table>
  </body>
</html>`)});let b="APPROVE"===g?"PAYMENT_PENDING":"REJECTED";return await w.db.update(y.vendorBookingsTable).set({status:b,updatedAt:new Date}).where((0,N.eq)(y.vendorBookingsTable.id,v.id)),R.NextResponse.json({success:!0,status:b})}catch(e){return console.error("Decision error:",e),R.NextResponse.json({error:"Internal server error"},{status:500})}}e.s(["POST",()=>A],77317);var C=e.i(77317);let D=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/vendors/bookings/[uuid]/decision/route",pathname:"/api/vendors/bookings/[uuid]/decision",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Documents/Nextjs/sr-portriats-events/src/app/api/vendors/bookings/[uuid]/decision/route.ts",nextConfigOutput:"",userland:C}),{workAsyncStorage:I,workUnitAsyncStorage:O,serverHooks:S}=D;function q(){return(0,n.patchFetch)({workAsyncStorage:I,workUnitAsyncStorage:O})}async function j(e,t,n){D.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let R="/api/vendors/bookings/[uuid]/decision/route";R=R.replace(/\/index$/,"")||"/";let x=await D.prepare(e,t,{srcPage:R,multiZoneDraftMode:!1});if(!x)return t.statusCode=400,t.end("Bad Request"),null==n.waitUntil||n.waitUntil.call(n,Promise.resolve()),null;let{buildId:w,params:y,nextConfig:E,parsedUrl:T,isDraftMode:N,prerenderManifest:P,routerServerContext:k,isOnDemandRevalidate:A,revalidateOnlyGenerated:C,resolvedPathname:I,clientReferenceManifest:O,serverActionsManifest:S}=x,q=(0,l.normalizeAppPath)(R),j=!!(P.dynamicRoutes[q]||P.routes[I]),_=async()=>((null==k?void 0:k.render404)?await k.render404(e,t,T,!1):t.end("This page could not be found"),null);if(j&&!N){let e=!!P.routes[I],t=P.dynamicRoutes[q];if(t&&!1===t.fallback&&!e){if(E.experimental.adapterPath)return await _();throw new b.NoFallbackError}}let $=null;!j||D.isDev||N||($="/index"===($=I)?"/":$);let B=!0===D.isDev||!j,M=j&&!B;S&&O&&(0,s.setReferenceManifestsSingleton)({page:R,clientReferenceManifest:O,serverActionsManifest:S,serverModuleMap:(0,i.createServerModuleMap)({serverActionsManifest:S})});let H=e.method||"GET",U=(0,a.getTracer)(),F=U.getActiveScopeSpan(),V={params:y,prerenderManifest:P,renderOpts:{experimental:{authInterrupts:!!E.experimental.authInterrupts},cacheComponents:!!E.cacheComponents,supportsDynamicResponse:B,incrementalCache:(0,o.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:E.cacheLife,waitUntil:n.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,n)=>D.onRequestError(e,t,n,k)},sharedContext:{buildId:w}},z=new d.NodeNextRequest(e),K=new d.NodeNextResponse(t),L=u.NextRequestAdapter.fromNodeNextRequest(z,(0,u.signalFromNodeResponse)(t));try{let s=async e=>D.handle(L,V).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=U.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=r.get("next.route");if(n){let t=`${H} ${n}`;e.setAttributes({"next.route":n,"http.route":n,"next.span_name":t}),e.updateName(t)}else e.updateName(`${H} ${R}`)}),i=!!(0,o.getRequestMeta)(e,"minimalMode"),l=async o=>{var a,l;let d=async({previousCacheEntry:r})=>{try{if(!i&&A&&C&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let a=await s(o);e.fetchMetrics=V.renderOpts.fetchMetrics;let l=V.renderOpts.pendingWaitUntil;l&&n.waitUntil&&(n.waitUntil(l),l=void 0);let d=V.renderOpts.collectedTags;if(!j)return await (0,g.sendResponse)(z,K,a,V.renderOpts.pendingWaitUntil),null;{let e=await a.blob(),t=(0,v.toNodeOutgoingHttpHeaders)(a.headers);d&&(t[h.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==V.renderOpts.collectedRevalidate&&!(V.renderOpts.collectedRevalidate>=h.INFINITE_CACHE)&&V.renderOpts.collectedRevalidate,n=void 0===V.renderOpts.collectedExpire||V.renderOpts.collectedExpire>=h.INFINITE_CACHE?void 0:V.renderOpts.collectedExpire;return{value:{kind:m.CachedRouteKind.APP_ROUTE,status:a.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:n}}}}catch(t){throw(null==r?void 0:r.isStale)&&await D.onRequestError(e,t,{routerKind:"App Router",routePath:R,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:A})},k),t}},u=await D.handleResponse({req:e,nextConfig:E,cacheKey:$,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:P,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:C,responseGenerator:d,waitUntil:n.waitUntil,isMinimalMode:i});if(!j)return null;if((null==u||null==(a=u.value)?void 0:a.kind)!==m.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(l=u.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});i||t.setHeader("x-nextjs-cache",A?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),N&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,v.fromNodeOutgoingHttpHeaders)(u.value.headers);return i&&j||c.delete(h.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,f.getCacheControlHeader)(u.cacheControl)),await (0,g.sendResponse)(z,K,new Response(u.value.body,{headers:c,status:u.value.status||200})),null};F?await l(F):await U.withPropagatedContext(e.headers,()=>U.trace(c.BaseServerSpan.handleRequest,{spanName:`${H} ${R}`,kind:a.SpanKind.SERVER,attributes:{"http.method":H,"http.target":e.url}},l))}catch(t){if(t instanceof b.NoFallbackError||await D.onRequestError(e,t,{routerKind:"App Router",routePath:q,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:A})}),j)throw t;return await (0,g.sendResponse)(z,K,new Response(null,{status:500})),null}}e.s(["handler",()=>j,"patchFetch",()=>q,"routeModule",()=>D,"serverHooks",()=>S,"workAsyncStorage",()=>I,"workUnitAsyncStorage",()=>O],25459)}];

//# sourceMappingURL=d281a_next_dist_esm_build_templates_app-route_b8456b74.js.map