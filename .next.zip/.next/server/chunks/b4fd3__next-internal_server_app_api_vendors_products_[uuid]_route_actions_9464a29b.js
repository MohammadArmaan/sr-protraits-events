module.exports=[1155,(e,o,d)=>{}];

//# sourceMappingURL=b4fd3__next-internal_server_app_api_vendors_products_%5Buuid%5D_route_actions_9464a29b.js.map