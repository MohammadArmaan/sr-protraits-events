module.exports=[8575,(e,o,d)=>{}];

//# sourceMappingURL=23b86_server_app_api_admin_vendor-registration_approve_route_actions_290d05af.js.map