globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2e396cd8ce12410b.js",
    "static/chunks/82d31ae96042f8a1.js",
    "static/chunks/726d36a41d86202f.js",
    "static/chunks/3cb047f683d42026.js",
    "static/chunks/d4e5c44b6943bf2e.js",
    "static/chunks/turbopack-523e79643b8a3109.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];