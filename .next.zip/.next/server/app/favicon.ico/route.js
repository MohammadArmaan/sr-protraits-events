var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__b01ab6e1._.js")
R.c("server/chunks/[root-of-the-server]__6d2c7922._.js")
R.c("server/chunks/d281a_next_dist_esm_build_templates_app-route_f02dce51.js")
R.c("server/chunks/b4fd3__next-internal_server_app_favicon_ico_route_actions_9aa144ac.js")
R.m(29754)
module.exports=R.m(29754).exports
