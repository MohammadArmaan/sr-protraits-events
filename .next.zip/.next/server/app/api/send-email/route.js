var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-email/route.js")
R.c("server/chunks/[root-of-the-server]__da70e66b._.js")
R.c("server/chunks/[root-of-the-server]__6d2c7922._.js")
R.c("server/chunks/[root-of-the-server]__3d8b9bbb._.js")
R.c("server/chunks/b4fd3__next-internal_server_app_api_send-email_route_actions_a8768457.js")
R.m(7926)
module.exports=R.m(7926).exports
