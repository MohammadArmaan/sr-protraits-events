var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/me/route.js")
R.c("server/chunks/[root-of-the-server]__d2641c1d._.js")
R.c("server/chunks/[root-of-the-server]__73f40451._.js")
R.c("server/chunks/[root-of-the-server]__6d2c7922._.js")
R.c("server/chunks/Documents_Nextjs_sr-portriats-events_e3822b4c._.js")
R.c("server/chunks/b4fd3__next-internal_server_app_api_admin_me_route_actions_23549f68.js")
R.m(21678)
module.exports=R.m(21678).exports
