var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/logout/route.js")
R.c("server/chunks/[root-of-the-server]__044f1953._.js")
R.c("server/chunks/[root-of-the-server]__6d2c7922._.js")
R.c("server/chunks/b4fd3__next-internal_server_app_api_admin_logout_route_actions_5da837d3.js")
R.m(91260)
module.exports=R.m(91260).exports
