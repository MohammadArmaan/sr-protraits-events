var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/vendor-cupons/route.js")
R.c("server/chunks/[root-of-the-server]__199f24cc._.js")
R.c("server/chunks/[root-of-the-server]__73f40451._.js")
R.c("server/chunks/[root-of-the-server]__6d2c7922._.js")
R.c("server/chunks/Documents_Nextjs_sr-portriats-events_e3822b4c._.js")
R.c("server/chunks/b4fd3__next-internal_server_app_api_admin_vendor-cupons_route_actions_80b8a601.js")
R.m(12304)
module.exports=R.m(12304).exports
